#!/bin/bash
cd Python-2.7.13/
make install

ln -s /usr/local/python/bin/python2.7 /usr/bin/python27

cd ..

cd pycrypto-2.6.1/
python27 setup.py build
python27 setup.py install

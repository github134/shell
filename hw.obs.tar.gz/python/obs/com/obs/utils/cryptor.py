#coding=utf-8

import os
import base64
from Crypto.Cipher import AES
from pbkdf2 import enable_pbkdf2

PASSWORD_KEY = "pw_key"
PASSWORD_IV = "pw_iv"
KEY_IV = "key_iv"
ASCII_MAX_VALUE = 256
LENGTH = 16
DEPENDENCY_PATH = 'tmp/decrypt_dependency.txt'

class AESCryptor(object):
    
    def aes_encrypt(self, text, key, iv):
        cryptor = AES.new(key, AES.MODE_CBC, iv)
        count = len(text)
        if count < LENGTH:
            add = LENGTH-count
            text = text + ('\0' * add)
        elif count > LENGTH:
            add = LENGTH-(count % LENGTH)
            text = text + ('\0' * add)
        return cryptor.encrypt(text)

    def decrypt_data(self, text, pw_key, pw_iv, key_iv):
        '''
        :param text: the text is decrypted
        :param key_pw: the key is used to encrypt the text
        :param iv_pw: the iv is used to encrypt the text
        :param iv_key: the key is used to encrypt key_pw
        :return:
        '''

        cipher_key = self._decrypt_key(pw_key, key_iv)
        cryptor = AES.new(cipher_key, AES.MODE_CBC, pw_iv)
        return cryptor.decrypt(text).strip('\0')

    def _decrypt_key(self, text, iv):
        key = enable_pbkdf2(base64.b64decode(self._get_init_vector()),
                            base64.b64decode(self._get_cfg_factor()))
        cryptor = AES.new(key, AES.MODE_CBC, iv)
        return cryptor.decrypt(text)

    def decrypt_dependency(self, *args):
        dir = os.path.dirname(os.path.realpath(__file__))
        if not args:
            args = [""]
        file_path = os.path.join(dir, DEPENDENCY_PATH+ args[0])
        try:
            with open(file_path, "r") as f:
                pw_key = None
                pw_iv = None
                key_iv = None
                for line in f.readlines():
                    line = line.strip().strip("\n")
                    if PASSWORD_KEY in line:
                        pw_key = base64.b64decode(
                            line.split(PASSWORD_KEY + "=")[1])
                    elif PASSWORD_IV in line:
                        pw_iv = base64.b64decode(
                            line.split(PASSWORD_IV + "=")[1])
                    elif KEY_IV in line:
                        key_iv = base64.b64decode(
                            line.split(KEY_IV + "=")[1])
                return pw_key, pw_iv, key_iv
        except Exception as ex:
            raise ex

    def _convert(self, avalue):
        if avalue > ASCII_MAX_VALUE - 1:
            avalue -= ASCII_MAX_VALUE
        elif avalue < 0:
            avalue += ASCII_MAX_VALUE
        return avalue

    def _get_init_vector(self):
        init_vector = [0x69, 0x1D, 0x10, 0x3B,
                       0xDB, 0x1B, 0x14, 0xBF,
                       0xA6, 0x83, 0xEE, 0x2E,
                       0xC9, 0xAD, 0x43, 0x60]

        init_vector[0] = self._convert(init_vector[13] & init_vector[14])
        init_vector[1] = self._convert(init_vector[12] & init_vector[11])
        init_vector[2] = self._convert(init_vector[9] + init_vector[2])
        init_vector[3] = self._convert(init_vector[8] + init_vector[9])
        init_vector[4] = self._convert(init_vector[10] & init_vector[4])
        init_vector[5] = self._convert(init_vector[0] - init_vector[8])
        init_vector[6] = self._convert(init_vector[2] - init_vector[11])
        init_vector[7] = self._convert(init_vector[12] + init_vector[8])
        init_vector[8] = self._convert(init_vector[3] & init_vector[10])
        init_vector[9] = self._convert(init_vector[11] | init_vector[15])
        init_vector[10] = self._convert(init_vector[13] - init_vector[15])
        init_vector[11] = self._convert(init_vector[6] | init_vector[1])
        init_vector[12] = self._convert(init_vector[6] | init_vector[1])
        init_vector[13] = self._convert(init_vector[10] | init_vector[15])
        init_vector[14] = self._convert(init_vector[10] + init_vector[14])
        init_vector[15] = self._convert(init_vector[10] & init_vector[2])

        return base64.b64encode(bytearray(init_vector))

    def _get_cfg_factor(self):
        dir = os.path.dirname(os.path.realpath(__file__))
        file_path = os.path.join(dir, "cfg_factor.txt")
        try:
            with open(file_path, "r") as f:
                factor = f.read().strip("\n").strip(" ")
        except Exception as ex:
            factor = ""
        return factor

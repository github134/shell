#coding=utf-8

import hashlib, hmac, base64
import binascii
import re
import time
import urllib   

import request_format
from com.obs.models.get_object_request import GetObjectRequest
import sys
reload(sys)
sys.setdefaultencoding("utf-8")
class Utils:
    
    METADATA_PREFIX = "x-amz-meta-"
    AMAZON_HEADER_PREFIX = "x-amz-"
    ALTERNATIVE_DATE_HEADER = "x-amz-date"
    DEFAULT_HOST = "127.0.0.1"
    
    SECURE_PORT = 443
    INSECURE_PORT = 80   

    parg_keys = ["acl", "lifecycle", "location", "logging", "notification"
                 , "partNumber", "policy","uploadId", "uploads", "versionId"
                 , "versioning", "versions", "website", "quota","storagePolicy"
                 , "storageinfo", "delete", "deletebucket", "response-content-type"
                 ,"response-content-language", "response-expires", "response-cache-control"
                 , "response-content-disposition","response-content-encoding","cors",'restore'
                 ]

    #==========================================================================
    # 构造待签名的串，如果过期时间（expires）为空，则使用HTTP头中的Date字段
    #==========================================================================
    @staticmethod
    def make_canonicalstring(method, bucket_name, key, path_args, headers, expires=None):
        
        str_list = [] 
        str_list.append(method + "\n")
        
        # 添加所有相关的头部字段（Content-MD5, Content-Type, Date和以x-amz开头的），并排序
        interesting_headers = {}  # 使用字典表示
        content_list = ["content-type", "content-md5", "date"]
        if headers:
            for hash_key in headers.keys():
                lk = hash_key.lower()  # headers的key值的小写
                
                # 忽略不相关的HTTP头字段
                if lk in content_list or lk.startswith(Utils.AMAZON_HEADER_PREFIX):                
                    s = headers.get(hash_key)  # 获得headers中的值列表
                    interesting_headers[lk] = ''.join(s)
                                                         
        # 如果有amz的时间标记就无需加入原有的date标记
        if Utils.ALTERNATIVE_DATE_HEADER in interesting_headers.keys():
            interesting_headers.setdefault("date", "")
        
        # 如果过期时间不为空，则将过期时间填入date字段中
        if expires:
            interesting_headers["date"] = expires
       
        # 这些字段必须要加入，故即使没有设置也要加入
        if not "content-type" in interesting_headers.keys():
            interesting_headers["content-type"] = ""

        if not "content-md5" in interesting_headers.keys():
            interesting_headers["content-md5"] = ""
        
        # 取出字典中的key并进行排序
        keylist = interesting_headers.keys()
        keylist.sort()
        
        # 最后加入所有相关的HTTP头部字段 (例如: 所有以x-amz-开头的)
        for k in keylist:
            header_key = str(k)
            if header_key.startswith(Utils.AMAZON_HEADER_PREFIX):
                str_list.append(header_key + ":" + interesting_headers[header_key])
            else:
                str_list.append(interesting_headers[header_key])
            str_list.append("\n")

        # 使用存储空间名和对象名构建路径
        if bucket_name:          
            str_list.append("/" + bucket_name)
             
        # 再加入一个反斜杠
        str_list.append("/")
        
        # 对象名不为空，则添加对象名到待签名的字符串中
        if key: 
            str_list.append(key)
        
        # 最后检查路径参数里是否有ACL，有则加入
        if path_args:
            if isinstance(path_args, (GetObjectRequest)):
                str_list.append(Utils.make_get_object_url(path_args))
                return ''.join(item for item in str_list) 
            e1 = '?'
            e2 = '&'
            for path_key in path_args.keys():
                if path_key in Utils.parg_keys:
                    if path_args[path_key] is None:
                        e1 += path_key + '&'
                    else:
                        e2 += path_key + "=" + str(path_args[path_key]) + '&'
             
            e = (e1 + e2).replace("&&", "&").replace('?&', '?')[:-1]    
            str_list.append(e) 
        return ''.join(item for item in str_list)  # 返回待签名的字符串      
    
    #===========================================================================
    # 计算字符串的hash值，采用HMAC/SHA1算法
    # @param secret_access_key 鉴权使用的SK
    # @param canonicalstring   待签名的字符串
    # @param urlencode         是否进行URL签名
    # @return String 签名（带SK的哈希值）
    #===========================================================================
    @staticmethod
    def encode(secret_access_key, canonicalstring, urlencode):    
        
        hashed = hmac.new(secret_access_key, canonicalstring, hashlib.sha1)  # 使用sha1算法创建hmac的对象
        encode_canonical = binascii.b2a_base64(hashed.digest())[:-1]  # 获得加密后的字符串，即hash值
        
        if urlencode:
            return Utils.urlencode(encode_canonical)
        else:
            return encode_canonical
        
    #===========================================================================
    # 校验路径方式的存储空间名
    # @return bool型值： True或False
    #===========================================================================
    @staticmethod
    def validate_bucketname(bucket_name, calling_format):

        if isinstance(calling_format, request_format.PathFormat):
            MIN_BUCKET_LENGTH = 3
            MAX_BUCKET_LENGTH = 63
            BUCKET_NAME_REGEX = "^[0-9A-Za-z\\.\\-_]*$"
            
            flag = bucket_name and Utils.length_in_range(bucket_name, MIN_BUCKET_LENGTH, MAX_BUCKET_LENGTH) and \
                   re.match(BUCKET_NAME_REGEX, bucket_name)  # \用于连接下一行字符            
            return flag
        
        else:
            return Utils.valid_subdomain_bucketname(bucket_name)
    
    
    #===========================================================================
    # 校验子域名的存储空间
    #===========================================================================    
    @staticmethod
    def valid_subdomain_bucketname(bucket_name):
        
        MIN_BUCKET_LENGTH = 3
        MAX_BUCKET_LENGTH = 63
        
        # 存储空间名不能是IP格式
        IPv4_REGEX = "^[0-9]+\\.[0-9]+\\.[0-9]+\\.[0-9]+$"
        # DNS子域名格式限制
        BUCKET_NAME_REGEX = "^[a-z0-9]([a-z0-9\\-]*[a-z0-9])?(\\.[a-z0-9]([a-z0-9\\-]*[a-z0-9])?)*$"       
        
        # 最后执行存储空间名检查
        flag = bucket_name \
                and Utils.length_in_range(bucket_name, MIN_BUCKET_LENGTH, MAX_BUCKET_LENGTH) \
                and not re.match(IPv4_REGEX, bucket_name) \
                and re.match(BUCKET_NAME_REGEX, bucket_name)
        
        return flag
    
    #===========================================================================
    # 检查存储空间的长度
    #===========================================================================
    @staticmethod
    def length_in_range(bucket_name, min_len, max_len):
        return len(bucket_name) >= min_len and len(bucket_name) <= max_len
       
    #===========================================================================
    # 获取存储空间的调用方式  
    #===========================================================================
    @staticmethod
    def get_callingformat_for_bucket(desired_format, bucket_name):  
         
        calling_format = desired_format
        if isinstance(calling_format, request_format.SubdomainFormat) and not Utils.valid_subdomain_bucketname(bucket_name):
            calling_format = request_format.RequestFormat.get_pathformat()
    
        return calling_format
     
         
    #===========================================================================
    # 将路径参数从map类型转换为字符串
    # @param path_args 参数hash表
    # @return String  转换后的路径参数字符串     
    #===========================================================================
    @staticmethod
    def convert_path_string(path_args): 
        if isinstance(path_args, (GetObjectRequest)):
            return Utils.make_get_object_url(path_args)
        e = ''
        if path_args:
            e1 = '?'
            e2 = '&'
            for path_key in path_args.keys():
                if path_key in Utils.parg_keys:
                    if path_args[path_key] is None:
                        e1 += path_key + '&'
                        continue
                e2 += path_key + "=" + urllib.quote(str(path_args[path_key]), " ,:?/=+&%") + '&'
            e = (e1 + e2).replace("&&", "&").replace('?&', '?')[:-1]  
        return e
  
         
    #===========================================================================
    # 时间格式的转换，将xml文件中的GMT时间转换为当地时间CST格式
    #===========================================================================
    @staticmethod
    def transfer_date(date):
        
        date_format = "%Y-%m-%dT%H:%M:%S.%fZ"  # xml文件中的时间格式
        CST_FORMAT = "%a %b %d %H:%M:%S CST %Y"  # 转换为CST格式的时间
    
        gmt_time = time.strptime(date, date_format)  # date是GMT格式的时间
        
        cst_time = time.localtime(time.mktime(gmt_time) - time.timezone)  # time.timezone是当前时区和0时区相差的描述，值为-28800=-8*3600，即为东八区
        dt = time.strftime(CST_FORMAT, cst_time)

        return dt     
    
    #===========================================================================
    # 将参数转换为字典dictionary类型
    # @param prefix
    # @param marker
    # @param max_keys
    # @param delimiter
    # @return
    #===========================================================================
    @staticmethod
    def params_for_dict_options(prefix, marker, max_keys, delimiter=None):
        
        args = {}
        
        # 这些参数必须使用url编码
        if prefix:
            args["prefix"] = Utils.urlencode(prefix)
        if marker:
            args["marker"] = Utils.urlencode(marker)
        if delimiter:
            args["delimiter"] = Utils.urlencode(delimiter)      
        if max_keys:
            args["max-keys"] = str(max_keys)
        
        return args
    
    #===========================================================================
    # 将对象转换为字典dictionary类型
    # @param object
    # @return
    #===========================================================================
    @staticmethod
    def object_to_dict(object):
        args = None
        if object:
            try:
                args = object.__dict__
            except Exception :
                args = object
            for o in args.keys():
                if args[o] == None:
                    del args[o]
        return args

        
    #==========================================================================
    # URL编码字符串
    # @param unencoded    待编码的字符串
    # @return URL编码后的字符串    
    #==========================================================================
    @staticmethod
    def urlencode(unencoded):
        params = {"q": unencoded.encode('UTF-8')}
        return urllib.urlencode(params).replace("q=", "").replace("%7E", "~")
    
    @staticmethod
    def decode_utf(undecoded):
        try:
            return undecoded.decode("UTF-8")
        except UnicodeDecodeError:
            return undecoded.decode("GB2312").encode("UTF-8")  # 处理中文路径问题

    @staticmethod
    def unencode(encode_str):
        return urllib.unquote(encode_str)  

    #==========================================================================
    # base64编码
    # @param unencoded    待编码的字符串
    # @return base64编码后的字符串    
    #==========================================================================
    @staticmethod
    def base64_encode(unencoded):
        encodeestr = base64.b64encode(unencoded, altchars=None)
        return encodeestr
    
    #==========================================================================
    # md5 字符串编码
    # @param unencoded    待编码的字符串
    # @return md5编码后的字符串    
    #==========================================================================
    @staticmethod
    def md5_encode(unencoded):
        m = hashlib.md5()
        m.update(unencoded)
        return m.digest()
    
    #==========================================================================
    # md5文件编码
    # @param file_path    文件路径
    # @return md5编码后的字符串    
    #==========================================================================
    @staticmethod
    def md5_file_encode(file_path=None):
        if file_path is not None:
            m = hashlib.md5()
            with open(unicode(file_path, "UTF-8"), 'rb') as fp:
                CHUNKSIZE = 65536
                while True:
                    data = fp.read(CHUNKSIZE)
                    if not data:
                        break
                    m.update(data)
            return m.digest()

    @staticmethod
    def safe_trans_file_path(file_path=None):
        if file_path is not None:
            try:
                return file_path.decode("GB2312")
            except UnicodeDecodeError:
                try:
                    return file_path.decode("UTF-8")
                except:
                    return file_path


    #==========================================================================
    # md5文件编码
    # @param file_path   文件路径
    # @param size        文件编码段长度
    # @param offset      文件起始偏移量
    # @return md5编码后的字符串
    #==========================================================================
    @staticmethod
    def md5_file_encode_by_size_offset(file_path=None, size=None, offset=None):
        if file_path is not None and size is not None and offset is not None:
            m = hashlib.md5()
            file_path = Utils.safe_trans_file_path(file_path)
            with open(file_path, 'rb') as fp:
                CHUNKSIZE = 65536
                fp.seek(offset)
                read_count = 0
                while read_count < size:
                    read_size = CHUNKSIZE if size - read_count >= CHUNKSIZE else size - read_count
                    data = fp.read(read_size)
                    read_count_once = len(data)
                    if read_count_once <= 0:
                        break
                    m.update(data)
                    read_count += read_count_once
            return m.digest()
    #==========================================================================
    # 拼接getObjectUrl
    # @param path_args   待编码的字符串
    # @return getObjectUrl    
    #==========================================================================
    @staticmethod
    def make_get_object_url(path_args):
        methodName = sys._getframe().f_back.f_back.f_back.f_back.f_code.co_name
        if isinstance(path_args, (GetObjectRequest)):
            return path_args.make_url(path_args)
        return None

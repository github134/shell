#coding=utf-8

import os
import base64

from cryptor import AESCryptor
from pbkdf2 import enable_pbkdf2

PASSWORD_KEY = "pw_key"
PASSWORD_IV = "pw_iv"
KEY_IV = "key_iv"

AES_ENCRYPT_LENGTH = 16

DEPENDENCY_PATH = 'tmp/decrypt_dependency.txt'


def get_dependency_path(type):
    dir = os.path.dirname(os.path.realpath(__file__))
    return os.path.join(dir, DEPENDENCY_PATH+type)


def encrypt_password(text, *args):
    aes_cryptor = AESCryptor()

    # get root key
    key = aes_cryptor._get_init_vector()
    _iv = aes_cryptor._get_cfg_factor()
    root_key = enable_pbkdf2(base64.b64decode(key),
                             base64.b64decode(_iv))

    # generate work key
    work_key = os.urandom(AES_ENCRYPT_LENGTH)

    # encrypt the work key
    work_key_iv = os.urandom(AES_ENCRYPT_LENGTH)

    try:
        cipher_work_key = aes_cryptor.aes_encrypt(work_key, root_key,
                                      work_key_iv)
    except Exception as ex:
        print "Failed to encrypt the work key: %s" % ex
        return
    # save the work key in config file
    # after it is encrypted
    if not args:
        args = [""]        
    
    dependency_file = get_dependency_path(args[0])
    if not os.path.exists(os.path.dirname(dependency_file)):
        os.makedirs(os.path.dirname(dependency_file), 0755)
    try:
        with open(dependency_file, "w") as file:
            file.truncate()
            password_key = "%s%s%s%s" % (PASSWORD_KEY, "=",
                                         base64.b64encode(cipher_work_key),
                                         "\n")
            file.write(password_key)

            # the iv is used to encrypt password
            pw_iv = os.urandom(AES_ENCRYPT_LENGTH)
            # save the iv in config file
            password_iv = "%s%s%s%s" % (PASSWORD_IV, "=",
                                        base64.b64encode(pw_iv),
                                        "\n")
            file.write(password_iv)

            # save the iv which is used to encrypt th work key
            key_vi = "%s%s%s%s" % (KEY_IV, "=",
                                   base64.b64encode(work_key_iv),
                                   "\n")
            file.write(key_vi)
            return aes_cryptor.aes_encrypt(text, work_key, pw_iv)
    except Exception as ex:
        print "Failed to save work key to %s" % dependency_file
        print ex.message

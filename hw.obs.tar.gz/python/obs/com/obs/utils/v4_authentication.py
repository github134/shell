#coding=utf-8

import time,datetime
import hashlib
import hmac
import types
from com.obs.utils.utils import Utils

CONTENT_SHA256 = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"

class V4Authentication(object):

    #===========================================================================
    # v4鉴权接口。
    #===========================================================================
    def __init__(self, sk, ak, region):
    #===========================================================================
    # @param ak 鉴权AK值
    # @param ak 鉴权SK值
    # @param region 服务器所在区域
    #===========================================================================
        self.ak = ak
        self.sk = sk
        self.utcTime = datetime.datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
        self.region = region
    
    #===========================================================================
    # v4鉴权调用接口
    #===========================================================================
    def v4Auth(self, method, bucket, object, args_path, headers):
    #===========================================================================
    # @param method 请求方式
    # @param bucket 桶名
    # @param object 对象名
    # @param args_path 请求的path，字典类型
    # @param headers 请求的head，字典类型
    # @return auth 鉴权之后的字符串
    #===========================================================================
        if args_path is None:
            args_path = {}
        if headers is None:
            headers = {}
        if ~headers.has_key("x-amz-content-sha256"):
            headers['x-amz-content-sha256'] = CONTENT_SHA256
        if headers.has_key("Date"):
            self.utcTime = time.strftime("%Y%m%dT%H%M%SZ", time.strptime(headers['Date'], "%a, %d %b %Y %H:%M:%S GMT"))
        elif headers.has_key('x-amz-date'):
            self.utcTime = headers['x-amz-date']
        credenttial = self.getCredenttial()
        signedHeaders = self.getSignedHeaders(headers)
        signature = self.getSignature(method, bucket, object, args_path, headers)   
        auth = "AWS4-HMAC-SHA256 " + "Credential=" + credenttial + "," + "SignedHeaders=" + signedHeaders + "," + "Signature=" + signature
        return auth
    
    #===========================================================================
    # 获取Credenttial值
    #===========================================================================
    def getCredenttial(self):
        shortDate = time.strftime("%Y%m%d", time.strptime(self.utcTime, "%Y%m%dT%H%M%SZ"))
        credenttial = self.ak + "/" + shortDate + "/" + self.region + "/"+"s3" + "/" + "aws4_request"
        return credenttial
    
    #===========================================================================
    # 获取Scope值
    #===========================================================================
    def getScope(self):
        shortDate = time.strftime("%Y%m%d", time.strptime(self.utcTime, "%Y%m%dT%H%M%SZ"))
        scope = shortDate + "/" + self.region + "/" + "s3" + "/" + "aws4_request"
        return scope
    
    #===========================================================================
    # 获取SignedHeaders值
    #===========================================================================    
    def getSignedHeaders(self,headers):
        headMap = self.setMapKeyLower(headers)
        headList = sorted(headMap.iteritems(),key = lambda d:d[0])
        signedHeaders = ""
        i = 0
        for val in headList:
            if i != 0:
                signedHeaders += ";"
            signedHeaders +=  val[0]
            i = 1
        return signedHeaders
 
    #===========================================================================
    # 获取Signature值
    #===========================================================================       
    def getSignature(self,method, bucket, object, args_path, headers):
        stringToSign = self.getStringToSign(method, bucket, object, args_path, headers)
        signingKey = self.getSigningKey()
        signature = hmac.new(signingKey, stringToSign, hashlib.sha256).hexdigest()
        return signature
            
    #===========================================================================
    # 获取SigningKey值
    #===========================================================================     
    def getSigningKey(self):
        shortDate = time.strftime("%Y%m%d", time.strptime(self.utcTime, "%Y%m%dT%H%M%SZ"))
        key = "AWS4" + self.sk
        dateKey = hmac.new(key, shortDate, hashlib.sha256).digest()
        dateRegionKey = hmac.new(dateKey, self.region, hashlib.sha256).digest()
        dateRegionServiceKey = hmac.new(dateRegionKey, "s3", hashlib.sha256).digest()
        signingKey = hmac.new(dateRegionServiceKey, "aws4_request", hashlib.sha256).digest()
        return signingKey
    
    #===========================================================================
    # 获取CanonicalRequest值
    #===========================================================================       
    def getCanonicalRequest(self,method,bucket,object,args_path,headers):
        outPut = method + "\n"
        outPut += self.getCanonicalURI(bucket, object) + "\n"
        outPut += self.getCanonicalQueryString(args_path) + "\n" 
        outPut += self.getCanonicalHeaders(headers) + "\n"
        outPut += self.getSignedHeaders(headers) + "\n"
        outPut += self.getHashedPayload()        
        return outPut

    #===========================================================================
    # 获取StringToSign值
    #===========================================================================      
    def getStringToSign(self,method, bucket, object, args_path, headers):
        shortDate = self.utcTime
        outPut = "AWS4-HMAC-SHA256" + "\n"
        outPut += shortDate + "\n"
        outPut += self.getScope() + "\n"
        cannonicalRequest = self.getCanonicalRequest(method, bucket, object, args_path, headers)
        outPut += hashlib.sha256(cannonicalRequest).hexdigest()
        return outPut
    
    #===========================================================================
    # 获取CanonicalURI值
    #===========================================================================  
    def getCanonicalURI(self,bucket=None,object=None):
        URI = "/"
        if bucket is not None and bucket != "":
            URI += bucket + "/"
        if object is not None and object != "":
            URI += object
        return URI

    #===========================================================================
    # 获取CanonicalQueryString值
    #===========================================================================     
    def getCanonicalQueryString(self,args_path):
        canonMap = {}
        for key in args_path.keys():
            value = args_path[key] if args_path[key] is not None else ""
            canonMap[key] = value
        cannoList = sorted(canonMap.iteritems(),key = lambda d:d[0])
        queryStr = ""
        i = 0
        for val in cannoList:
            if i != 0:
                queryStr += "&"
            queryStr += '%s=%s'%(val[0],val[1])
            i = 1
        return queryStr

    #===========================================================================
    # 获取CanonicalHeaders值
    #===========================================================================       
    def getCanonicalHeaders(self,headers):
        headMap = self.setMapKeyLower(headers)
        headList = sorted(headMap.iteritems(),key = lambda d:d[0])
        canonicalHeaderStr = ""
        for val in headList:
            if type(val[1]) is types.ListType:
                tlist = sorted(val[1])
                for v in tlist:
                    canonicalHeaderStr += val[0] + ":" + v + "\n"
            else:
                canonicalHeaderStr += val[0] + ":" + str(val[1]) + "\n"
        return canonicalHeaderStr

    #===========================================================================
    # 获取HashedPayload值
    #===========================================================================      
    def getHashedPayload(self):
        return CONTENT_SHA256
    
    #===========================================================================
    # 将字典的key值转换为小写
    #===========================================================================
    def setMapKeyLower(self,inputMap):
        outputMap = {}
        for key in inputMap.keys():
            outputMap[key.lower()] = inputMap[key]
        return outputMap
    
        
#coding=utf-8

from com.obs.models.date_time import DateTime

class CopyObjectHeader(object):
    #===========================================================================
    #  描述复制对象的请求消息头
    #===========================================================================

    def __init__(self, acl=None, directive=None, if_match=None, if_none_match=None, if_modified_since=None, if_unmodified_since=None, location=None):
        #===========================================================================
        # 初始化请求参数
        # @param acl 复制对象时，可以加上此消息头设置对象的权限控制策略，使用的策略为预定义的常用策略，包括：private；public-read；public-read-write；authenticated-read；bucket-owner-read；bucket-owner-full-control。
        # @param directive 此参数用来指定新对象的元数据是从源对象中复制，还是用请求中的元数据替换。有效取值：COPY或REPLACE。
        # @param if_match 如果对象的ETag和请求中指定的ETag相同，则返回对象内容，否则的话返回412（precondition failed）。
        # @param if_none_match 如果对象的ETag和请求中指定的ETag不相同，则返回对象内容，否则的话返回304（not modified）。
        # @param if_modified_since DateTime对象， 如果对象在请求中指定的时间之后有修改，则返回对象内容；否则的话返回304（not modified）。
        # @param if_unmodified_since DateTime对象 ，如果对象在请求中指定的时间之后没有修改，则返回对象内容；否则的话返回412（precondition failed）。
        # @param location 当桶设置了Website配置，可以将获取这个对象的请求重定向到桶内另一个对象或一个外部的URL，UDS将这个值从头域中取出，保存在对象的元数据中。
        #===========================================================================
        self.acl = acl
        self.directive = directive
        self.if_match = if_match
        self.if_none_match = if_none_match
        self.if_modified_since = if_modified_since
        self.if_unmodified_since = if_unmodified_since
        self.location = location

    def assemble_args(self):
        headers = {}
        if self.acl :
            headers["x-amz-acl"] = self.acl
        if self.directive :
            headers["x-amz-metadata-directive"] = self.directive
        if self.if_match :
            headers["x-amz-copy-source-if-match"] = self.if_match
        if self.if_none_match :
            headers["x-amz-copy-source-if-none-match"] = self.if_none_match
        if self.if_modified_since :
            if isinstance(self.if_modified_since, (DateTime)):
                headers["x-amz-copy-source-if-modified-since"] = self.if_modified_since.ToGMTTime()
            else:
                headers["x-amz-copy-source-if-modified-since"] = self.if_modified_since
        if self.if_unmodified_since :
            if isinstance(self.if_unmodified_since, (DateTime)):
                headers["x-amz-copy-source-if-unmodified-since"] = self.if_unmodified_since.ToGMTTime()
            else:
                headers["x-amz-copy-source-if-unmodified-since"] = self.if_unmodified_since
        if self.location :
            headers["x-amz-website-redirect-location"] = self.location
        return headers

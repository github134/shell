#coding=utf-8

class RedirectAllRequestTo(object):
    '''
    classdocs
    '''


    def __init__(self, hostName=None, Protocol=None):
        '''
        Constructor
        '''
        self.hostName = hostName
        self.Protocol = Protocol
    
    def to_xml(self):
        xml_list = []
        if self.hostName is not None:
            name = '<HostName>' + self.hostName + '</HostName>'
            xml_list.append(name)
        if self.Protocol is not None:
            prot = '<Protocol>' + self.Protocol + '</Protocol>'
            xml_list.append(prot)
        s1 = ''
        if len(xml_list) != 0:           
            s = ''.join(item for item in xml_list)
            s1 = '<RedirectAllRequestsTo>' + s + '</RedirectAllRequestsTo>'
        return s1

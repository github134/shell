#coding=utf-8

import os, sys

class DeleteObjectsRequset(object):
    #===========================================================================
    # 批量删除对象请求。
    #===========================================================================
    quiet = None
    #===========================================================================
    # 用于指定使用quiet模式，只返回删除失败的对象结果；如果有此字段，则必被置为True，如果为False则被系统忽略掉。
    #===========================================================================
    objects = []
    #===========================================================================
    # 待删除的对象列表。
    #===========================================================================

    def __init__(self, quiet=None, objects=None):
        self.quiet = quiet
        self.objects = objects
    
    def add_object(self, object):
        self.objects.append(object)  
        
    #===========================================================================
    # 将访问控制列表转换为xml字符串  保存到文件中
    # @return String 返回文件的路径
    #===========================================================================
    def to_xml(self):
        
        str_list = []
        str_list.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")
        str_list.append("<Delete>")
        if self.quiet:
            str_list.append("<Quiet>" + str(self.quiet).lower() + "</Quiet>")
        
        for obj in self.objects:
            str_list.append("<Object><Key>" + str(obj.key) + "</Key>")
            if obj.versionId:
                str_list.append("<VersionId>" + str(obj.versionId) + "</VersionId>")
            str_list.append("</Object>")
        
        str_list.append("</Delete>")
        
        s = ''.join(item for item in str_list)
       
        path = os.path.abspath(os.path.dirname(sys.argv[0]))
        with open(os.path.join(path, "delete_objects.xml"), 'wb') as f:
            f.write(s)
        return os.path.join(path, "delete_objects.xml")  # 返回文件的路径名
        
class Object(object):
    #===========================================================================
    # 待删除的对象。
    #===========================================================================
    key = None
    #===========================================================================
    # 待删除的对象Key。
    #===========================================================================
    versionId = None
    #===========================================================================
    # 待删除的对象版本号。
    #===========================================================================
    def __init__(self, key=None, versionId=None):
        self.key = key
        self.versionId = versionId

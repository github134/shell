#coding=utf-8

from com.obs.models.date_time import DateTime

class Expiration(object):
    '''
    classdocs
    '''


    def __init__(self, date = None,days = None):  
        '''
        Constructor
		date:支持DateTime格式和UTC标准时间格式
        '''
        
        if isinstance(date,(DateTime)):
            self.date = date.ToUTTime()
        else:
            self.date = date
        self.days = days
        
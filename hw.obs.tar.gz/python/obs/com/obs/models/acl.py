#coding=utf-8

import os, sys
import xml.etree.ElementTree as ET

from com.obs.models.owner import Owner
from com.obs.models.grant import Grant
from com.obs.models.grantee import Grantee
from com.obs.response.nameSpace import NameSpace

#===============================================================================
# 访问控制列表
#===============================================================================
class ACL(object):
    
    def __init__(self, owner=None, grants=None):
        self.owner = owner  # 资源拥有者
        self.grants = grants  # 访问控制列表
    
    #===========================================================================
    # 添加授权对象    
    #===========================================================================
    def add_grant(self, grant):
        self.grants.append(grant)
    
    #===========================================================================
    # 将访问控制列表转换为xml字符串  保存到文件中
    # @return String 返回文件的路径
    #===========================================================================
    def to_xml(self):
        
        if not self.owner: 
            raise Exception("Invalid AccessControlList: missing an S3 Owner")

        str_list = []
        str_list.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")
        str_list.append("<AccessControlPolicy xmlns=\"http://s3.amazonaws.com/doc/2006-03-01/\"><Owner><ID>")
        str_list.append(self.owner.owner_id + "</ID><DisplayName>" + self.owner.owner_name + "</DisplayName>")
        str_list.append("</Owner><AccessControlList>")
        
        for acl in self.grants:
            grantee = acl.grantee
            permission = acl.permission
            str_list.append("<Grant>" + grantee.to_xml() + "<Permission>" + str(permission) + "</Permission></Grant>")
        
        str_list.append("</AccessControlList></AccessControlPolicy>")
        
        s = ''.join(item for item in str_list)
       
        path = os.path.abspath(os.path.dirname(sys.argv[0]))
        with open(path + "\\acl.xml", 'wb') as f:
            f.write(s)
    
        return path + "\\acl.xml"  # 返回文件的路径名

    #===========================================================================
    # 定义静态方法，用来解析xml，最后返回ACL对象
    #===========================================================================
    @staticmethod    
    def parse_xml(xml):
        
        if xml is not None:
            owner = ListACL.parse_owner(xml)
            grants = ListACL.parse_grant(xml)
            return ACL(owner, grants)  # 返回ACL的对象
   

class ListACL:
    
    ns = '{http://www.w3.org/2001/XMLSchema-instance}'
    NS = NameSpace.getNameSpace()
    
    #===========================================================================
    # 获取Owner相关信息
    #===========================================================================
    @staticmethod
    def parse_owner(xml): 
        ListACL.NS = NameSpace.getNameSpace()    
        root = ET.fromstring(xml)
        owner_id = root.find('.//{0}ID'.format(ListACL.NS)).text      
        owner_name = root.find('.//{0}DisplayName'.format(ListACL.NS)).text    
        owner = Owner(owner_id, owner_name)  # 创建Owner对象
        return owner 

    #===========================================================================
    # 获取Grant相关信息
    #===========================================================================
    @staticmethod
    def parse_grant(xml):
        ListACL.NS = NameSpace.getNameSpace()
        root = ET.fromstring(xml)
        grants = root.findall('./{0}AccessControlList/{0}Grant'.format(ListACL.NS))
        grant_list = []
        
        for grant in grants:
            if grant.find('./{0}Grantee'.format(ListACL.NS)).attrib.get('{0}type'.format(ListACL.ns)) == "Group":
                group1 = grant.find('./{0}Grantee/{0}URI'.format(ListACL.NS)).text
                group1 =  group1[group1.rfind("/") + 1:]
                grantee = Grantee(group=group1)                                          
            elif grant.find('./{0}Grantee'.format(ListACL.NS)).attrib.get('{0}type'.format(ListACL.ns)) == "CanonicalUser":
                owner_id = grant.find('./{0}Grantee/{0}ID'.format(ListACL.NS)).text
                owner_name = grant.find('./{0}Grantee/{0}DisplayName'.format(ListACL.NS)).text
                grantee = Grantee(owner_id, owner_name)
            
            permission = grant.find('{0}Permission'.format(ListACL.NS)).text
            
            cur_grant = Grant(grantee, permission)
            grant_list.append(cur_grant)
            
        return grant_list
    

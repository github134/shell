#coding=utf-8

class Grantee(object):
    
    def __init__(self, grantee_id = None, grantee_name = None, group = None):
        self.grantee_id = grantee_id
        self.grantee_name = grantee_name
        self.group = group
    
 
    #===========================================================================
    # 转换为xml字符串
    # @return String 
    #===========================================================================
    def to_xml(self):
        
        str_list = []
        
        if self.group:
            str_list.append("<Grantee xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:type=\"Group\">")
            if self.group == Group.ALL_USERE:
                str_list.append("<URI>http://acs.amazonaws.com/groups/global/AllUsers</URI>")
            elif self.group == Group.AUTHENTICATED_USERS:        
                str_list.append("<URI>http://acs.amazonaws.com/groups/global/AuthenticatedUsers</URI>")
            elif self.group == Group.LOG_DELIVERY:
                str_list.append("<URI>http://acs.amazonaws.com/groups/s3/LogDelivery</URI>")
            str_list.append("</Grantee>")
        
        if self.grantee_id is not None and self.grantee_name is not None:
            str_list.append("<Grantee xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:type=\"CanonicalUser\">")
            if self.grantee_id is not None:
                str_list.append("<ID>" + self.grantee_id + "</ID>")
            if self.grantee_name is not None:
                str_list.append("<DisplayName>" + self.grantee_name + "</DisplayName>")
            str_list.append("</Grantee>")
                       
        return ''.join(item for item in str_list)



class Group:   
    
    ALL_USERE = "AllUsers"
    AUTHENTICATED_USERS = "AuthenticatedUsers"
    LOG_DELIVERY = "LogDelivery"
     
    
    
    
    
#coding=utf-8

class Options(object):
    '''
    classdocs
    '''


    def __init__(self, origin=None,accessControlRequestMethods = None,accessControlRequestHeaders = None):
        '''
        Constructor
        '''
        self.origin = origin
        if not accessControlRequestMethods:
            accessControlRequestMethods = []
        self.accessControlRequestMethods = accessControlRequestMethods
        if not accessControlRequestHeaders:
            accessControlRequestHeaders = []
        self.accessControlRequestHeaders = accessControlRequestHeaders
        
    def to_header(self):
        headers = {}
        if self.origin is not None and self.origin != "":
            headers['Origin'] = self.origin
        tempList = []
        for v in self.accessControlRequestMethods:
            tempList.append(v)
        if len(tempList) != 0:           
            headers['Access-Control-Request-Method'] = tempList
        tempList = []
        for v in self.accessControlRequestHeaders:
            tempList.append(v)
        if len(tempList) != 0:  
            headers['Access-Control-Request-Headers'] = tempList
         
        return headers
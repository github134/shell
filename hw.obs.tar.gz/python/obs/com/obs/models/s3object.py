#coding=utf-8

#===============================================================================
# 模拟S3对象，包括元数据(metadata)和对象文件的路径
#===============================================================================
class S3Object(object):

    #===========================================================================
    # 初始化
    # @param file_path 对象文件路径
    # @param metadata  对象元数据
    # @param file_size 对象文件大小
    #===========================================================================
    def __init__(self, file_path=None, metadata=None, file_size=None):
        self.file_path = file_path
        self.metadata = metadata
        self.file_size = file_size
        
        
        
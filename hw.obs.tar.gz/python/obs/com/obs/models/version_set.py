#coding=utf-8

import os,sys

class Version(object):
    '''
    classdocs
    '''


    def __init__(self):
        '''
        Constructor
        '''
    @staticmethod
    def to_xml(status): 
         
        xml = '<VersioningConfiguration>' 
        if status is not None:
            xml += '<Status>' + status + '</Status>'
        xml += '</VersioningConfiguration>' 
        
        path = os.path.abspath(os.path.dirname(sys.argv[0]))
        with open(path + "\\vsreion.xml", 'wb') as f:
            f.write(xml)
    
        return path + "\\vsreion.xml"  #返回文件的路径名 
#coding=utf-8

class PutObjectHeader(object):
    #===========================================================================
    #  描述上传对象的请求消息头
    #===========================================================================

    def __init__(self, md5=None, acl=None, location=None):
        #===========================================================================
        # 初始化请求参数
        # @param md5 对象数据的128位MD5摘要以Base64编码的方式表示。
        # @param acl 创建对象时，可以加上此消息头设置对象的权限控制策略，使用的策略为预定义的常用策略，包括：private；public-read；public-read-write；authenticated-read；bucket-owner-read；bucket-owner-full-control。
        # @param location 当桶设置了Website配置，可以将获取这个对象的请求重定向到桶内另一个对象或一个外部的URL，MOS将这个值从头域中取出，保存在对象的元数据中。
        #===========================================================================
        self.md5 = md5
        self.acl = acl
        self.location = location
    
    def assemble_args(self):
        headers = {}
        if self.md5 :
            headers["Content-MD5"] = self.md5
        if self.acl :
            headers["x-amz-acl"] = self.acl
        if self.location :
            headers["x-amz-website-redirect-location"] = self.location
        return headers

 

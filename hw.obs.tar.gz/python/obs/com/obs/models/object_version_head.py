#coding=utf-8

class ObjectVersionHead(object):
    '''
    classdocs
    '''

    def __init__(self,  Name = None,
                        Prefix = None,
                        KeyMarker = None,
                        VersionIdMarker = None,
                        NextKeyMarker = None,
                        NextVersionIdMarker = None,
                        MaxKeys = None,
                        IsTruncated = None):
        '''
        Constructor
        '''
        self.name = Name
        self.prefix = Prefix
        self.keyMarker = KeyMarker
        self.versionIdMarker = VersionIdMarker
        self.nextKeyMarker = NextKeyMarker
        self.nextVersionIdMarker = NextVersionIdMarker
        self.maxKeys = MaxKeys
        self.isTruncated = IsTruncated
        
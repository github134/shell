#coding=utf-8

class Versions(object):
    '''
    classdocs
    '''



    def __init__(self,     
                prefix = None,
                key_marker = None,
                max_keys = None,
                delimiter = None,
                version_id_marker = None):
        '''
        Constructor
        '''
        self.prefix = prefix
        self.key_marker = key_marker
        self.max_keys = max_keys
        self.delimiter = delimiter
        self.version_id_marker = version_id_marker
   
    def assembleToDict(self):

        path_args = {}
        path_args["versions"] = None
        if self.prefix:
            path_args['prefix'] = self.prefix
        if self.key_marker:
            path_args['key-marker'] = self.key_marker
        if self.max_keys:
            path_args['max-keys'] = self.max_keys
        if self.delimiter:
            path_args['delimiter'] = self.delimiter
        if self.version_id_marker:
            path_args['version-id-marker'] = self.version_id_marker
    
        return path_args
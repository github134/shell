#coding=utf-8

class Redirect(object):
    '''
    classdocs
    '''

    def __init__(self, Protocol = None,
                        HostName = None,
                        ReplaceKeyPrefixWith = None,
                        ReplaceKeyWith = None,
                        HttpRedirectCode = None):
        '''
        Constructor
        '''
        self.protocol = Protocol
        self.hostName = HostName
        self.replaceKeyPrefixWith = ReplaceKeyPrefixWith
        self.replaceKeyWith = ReplaceKeyWith
        self.httpRedirectCode = HttpRedirectCode 
    
    def to_xml(self):
        xml_list = []
        if self.protocol is not None:
            xml = '<Protocol>' + self.protocol + '</Protocol>'
            xml_list.append(xml)
        if self.hostName is not None:
            xml = '<HostName>' + self.hostName + '</HostName>'
            xml_list.append(xml)
        if self.replaceKeyPrefixWith is not None:
            xml = '<ReplaceKeyPrefixWith>' + self.replaceKeyPrefixWith + '</ReplaceKeyPrefixWith>'
            xml_list.append(xml)
        if self.replaceKeyWith is not None:
            xml = '<ReplaceKeyWith>' + self.replaceKeyWith + '</ReplaceKeyWith>'
            xml_list.append(xml)
        if self.httpRedirectCode is not None:
            xml = '<HttpRedirectCode>' + str(self.httpRedirectCode) + '</HttpRedirectCode>'
            xml_list.append(xml)
        s1 = ''
        if len(xml_list) != 0:
            s = ''.join(item for item in xml_list)
            s1 = '<Redirect>' + s + '</Redirect>'           
        return s1
            
        
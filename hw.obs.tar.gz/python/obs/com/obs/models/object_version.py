#coding=utf-8

from com.obs.models.owner import Owner

class ObjectVersion(object):
    '''
    classdocs
    '''

    def __init__(self, key = None,
                        versionId = None,
                        isLatest = None,
                        lastModified = None,
                        eTag = None,
                        size = None,
                        owner = Owner(),
                        storageClass = None,):
        '''
        Constructor
        '''
        self.key = key
        self.versionId = versionId
        self.isLatest = isLatest
        self.lastModified = lastModified
        self.eTag = eTag
        self.size = size
        self.owner = owner
        self.storageClass = storageClass
 
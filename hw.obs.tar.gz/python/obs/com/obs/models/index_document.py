#coding=utf-8

class IndexDocument(object):
    '''
    classdocs
    '''


    def __init__(self, Suffix=None):
        '''
        Constructor
        '''
        self.suffix = Suffix
    def to_xml(self):
        xml = ''
        if self.suffix is not None:
            xml += '<IndexDocument>'
            xml += '<Suffix>' + str(self.suffix) + '</Suffix>'
            xml  += '</IndexDocument>'
        return xml
#-*- coding:utf-8 -*-

import os,sys
from com.obs.utils.utils import Utils

class Restore(object):

    def __init__(self, days, tier=None):
        self.days = days
        self.tier = tier

    def to_xml(self):
        if not self.days:
            raise Exception('Invalid Restore Request: missing days parameter')

        str_list = ['<RestoreRequest xmlns="http://s3.amazonaws.com/doc/2006-03-01/" ><Days>',str(self.days),'</Days>']
        if self.tier:
            str_list.append('<GlacierJobParameters><Tier>')
            str_list.append(str(self.tier))
            str_list.append('</Tier></GlacierJobParameters>')
        str_list.append('</RestoreRequest>')
        return ''.join(str_list)

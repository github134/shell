#coding=utf-8

from com.obs.models.owner import Owner
from com.obs.models.initiator import Initiator

class Upload(object):
    '''
    classdocs
    '''
    

    def __init__(self,key=None,uploadID=None,initiator=Initiator(),owner=Owner(),storageClass=None,initiated=None ):
        '''
        Constructor
        '''
        self.key = key
        self.uploadID = uploadID
        self.initiator = initiator
        self.owner = owner
        self.storageClass = storageClass
        self.initiated = initiated
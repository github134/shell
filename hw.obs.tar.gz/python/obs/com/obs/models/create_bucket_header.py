#coding=utf-8

import os
import sys


class CreateBucketHeader(object):
    '''
    classdocs
    '''


    def __init__(self, aclControl=None,storageClass= None):
        '''
        Constructor
        '''
        self.aclControl = aclControl
        self.storageClass = storageClass

    
    

    def assembleHeader(self):
        headers = {}
        if self.aclControl:
            headers['x-amz-acl'] = self.aclControl
        if self.storageClass:
            headers['x-default-storage-class'] = self.storageClass
        return headers if len(headers) > 0 else None
    
    @staticmethod
    def to_xml(location):
        if location is  None:
            return None
        s = '<CreateBucketConfiguration xmlns="http://s3.amazonaws.com/doc/2006-03-01/">'
        s += '<LocationConstraint>' + str(location) + '</LocationConstraint>'
        s += '</CreateBucketConfiguration>'
        
        path = os.path.abspath(os.path.dirname(sys.argv[0]))
        with open(path + "\\creatBucket.xml", 'wb') as f:
            f.write(s)
    
        return path + "\\creatBucket.xml" 

#coding=utf-8

import os, sys

from com.obs.response.nameSpace import NameSpace
import xml.etree.ElementTree as ET


class CorsRule(object):
    '''
    classdocs
    '''

    def __init__(self,id=None,allowedMethod=None,allowedOrigin=None,allowedHeader=None,maxAgeSecond=None,exposeHeader=None):
        '''
        Constructor
        '''
        self.id = id
        self.allowedMethod = allowedMethod
        self.allowedOrigin = allowedOrigin
        self.allowedHeader = allowedHeader
        self.maxAgeSecond = maxAgeSecond
        self.exposeHeader = exposeHeader
    
    @staticmethod
    def to_xml(corsList=None):
        xml = []
        xml.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")
        xml.append("<CORSConfiguration xmlns=\"http://s3.amazonaws.com/doc/2006-03-01/\">")
        for cors in corsList:
            xml.append("<CORSRule>")
            if cors.id is not None:
                xml.append("<ID>" + str(cors.id) + "</ID>")
            for v in cors.allowedMethod:
                xml.append("<AllowedMethod>" + str(v) + "</AllowedMethod>")
            for v in cors.allowedOrigin:
                xml.append("<AllowedOrigin>" + str(v) + "</AllowedOrigin>")
            for v in cors.allowedHeader:
                xml.append("<AllowedHeader>" + str(v) + "</AllowedHeader>")  
            if cors.maxAgeSecond is not None:
                xml.append("<MaxAgeSeconds>" + str(cors.maxAgeSecond) + "</MaxAgeSeconds>") 
            for v in cors.exposeHeader:
                xml.append("<ExposeHeader>" + str(v) + "</ExposeHeader>") 
            xml.append("</CORSRule>")
            
        xml.append("</CORSConfiguration>")
        
        s = ''.join(item for item in xml)    
        path = os.path.abspath(os.path.dirname(sys.argv[0]))
        with open(path + "\\cors.xml", 'wb') as f:
            f.write(s)
    
        return path + "\\cors.xml"  # 返回文件的路径名
    
    @staticmethod
    def  parse_xml(xml):
        NS = NameSpace.getNameSpace()
        if not xml:
            return None
        i = 0
        root = ET.fromstring(xml)
        rules = root.findall('./{0}CORSRule'.format(NS))
        if len(rules) == 0:
            return None 
            
        corsList = []
        for rule in rules:
            id = rule.find("./{0}ID".format(NS))
            id = id.text if id is not None else None
            maxAgeSecond = rule.find("./{0}MaxAgeSeconds".format(NS))
            maxAgeSecond = maxAgeSecond.text if maxAgeSecond is not None else None
            
            method = rule.findall("./{0}AllowedMethod".format(NS))
            allowMethod = []
            if method is not None:
                i = 1
                for v in method:
                    allowMethod.append(v.text)
            allowedOrigin = []
            method = rule.findall("./{0}AllowedOrigin".format(NS))
            if method is not None:
                i = 1
                for v in method:
                    allowedOrigin.append(v.text)
            allowedHeader = []
            method = rule.findall("./{0}AllowedHeader".format(NS))
            if method is not None:
                i = 1
                for v in method:
                    allowedHeader.append(v.text)
            exposeHeader = []
            method = rule.findall("./{0}ExposeHeader".format(NS))
            if method is not None:
                i = 1
                for v in method:
                    exposeHeader.append(v.text)
            if id is None and maxAgeSecond is None and i == 0:
                corsList.append(None)
            else:
                corsList.append(CorsRule(id,allowMethod,allowedOrigin,allowedHeader,maxAgeSecond,exposeHeader))
        for cors in corsList:
            if cors is not None:
                return corsList
        return None
        
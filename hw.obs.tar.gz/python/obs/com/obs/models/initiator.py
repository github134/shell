#coding=utf-8

class Initiator(object):
    '''
    classdocs
    '''


    def __init__(self, id=None,name=None):
        '''
        Constructor
        '''
        self.id = id
        self.name = name
#coding=utf-8

class Website(object):
    '''
    classdocs
    '''


    def __init__(self, params):
        '''
        Constructor
        '''
        
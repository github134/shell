#coding=utf-8

from com.obs.models.date_time import DateTime

class GetObjectHeader(object):
    #===========================================================================
    #  描述获取对象的请求消息头
    #===========================================================================

    def __init__(self, range=None, if_modified_since=None, if_unmodified_since=None, if_match=None, if_none_match=None):
        #===========================================================================
        # 初始化请求参数
        # @param range 获取对象时获取在Range范围内的对象内容；如果Range不合法则忽略此字段下载整个对象;Range是一个范围，它的起始值最小为0，最大为对象长度减1。
        # @param if_modified_since DateTime对象，如果对象在请求中指定的时间之后有修改，则返回对象内容；否则的话返回304（not modified）。
        # @param if_unmodified_since DateTime对象，如果对象在请求中指定的时间之后没有修改，则返回对象内容；否则的话返回412（precondition failed）。
        # @param if_match 如果对象的ETag和请求中指定的ETag相同，则返回对象内容，否则的话返回412（precondition failed）。
        # @param if_none_match 如果对象的ETag和请求中指定的ETag不相同，则返回对象内容，否则的话返回304（not modified）。
        #===========================================================================
        self.range = range
        self.if_modified_since = if_modified_since
        self.if_unmodified_since = if_unmodified_since
        self.if_match = if_match
        self.if_none_match = if_none_match
        
    def assemble_args(self):
        headers = {}
        if self.range :
            headers["Range"] = "bytes=" + str(self.range)
        if self.if_modified_since :
            if isinstance(self.if_modified_since, (DateTime)):
                headers["If-Modified-Since"] = self.if_modified_since.ToGMTTime()
            else:
                headers["If-Modified-Since"] = self.if_modified_since
        if self.if_unmodified_since :
            if isinstance(self.if_unmodified_since, (DateTime)):
                headers["If-Unmodified-Since"] = self.if_unmodified_since.ToGMTTime()
            else:
                headers["If-Unmodified-Since"] = self.if_unmodified_since
        if self.if_match :
            headers["If-Match"] = self.if_match
        if self.if_none_match :
            headers["If-None-Match"] = self.if_none_match
        return headers

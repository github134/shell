#coding=utf-8

import sys, urllib
reload(sys)
sys.setdefaultencoding("utf-8")

class GetObjectRequest(object):
    #===========================================================================
    #  描述获取对象的请求
    #===========================================================================

    def __init__(self, content_type=None, content_language=None, expires=None, cache_control=None, content_disposition=None, content_encoding=None, versionId=None):
        #===========================================================================
        # 初始化请求参数
        # @param content_type 重写响应中的Content-Type头。
        # @param contecontent_languagent_type     重写响应中的Content-Language头。
        # @param expires     重写响应中的Expires头。
        # @param cache_control     重写响应中的Cache-Control头。
        # @param content_disposition     重写响应中的Content-Disposition头。
        # @param content_encoding     重写响应中的Content-Encoding头。
        # @param versionId     指定获取对象的版本号。
        #===========================================================================
        self.content_type = content_type
        self.content_language = content_language
        self.expires = expires
        self.cache_control = cache_control
        self.content_disposition = content_disposition
        self.content_encoding = content_encoding
        self.versionId = versionId
    
    @staticmethod
    def make_url(path_args):
        e1 = '?'
        temp = ""
        if path_args.cache_control is not None:
            temp += "response-cache-control=" + str(path_args.cache_control) + "&"
        if path_args.content_disposition is not None:
            temp += "response-content-disposition=" + str(path_args.content_disposition) + "&"
        if path_args.content_encoding is not None:
            temp += "response-content-encoding=" + str(path_args.content_encoding) + "&"
        if path_args.content_language is not None:
            temp += "response-content-language=" + str(path_args.content_language) + "&"
        if path_args.content_type is not None:
            temp += "response-content-type=" + str(path_args.content_type) + "&"
        if path_args.expires is not None:
            temp += "response-expires=" + str(path_args.expires) + "&"
        if path_args.versionId is not None:
            temp += "versionId=" + str(path_args.versionId) + "&"
        e = (e1 + urllib.quote(str(temp), " ,:?/=+&"))[:-1]
        return e
    
    def getArgsPath(self):
        outPutMap = {}
        if self.cache_control is not None:
            outPutMap['response-cache-control'] = str(self.cache_control)
        if self.content_disposition is not None:
            outPutMap["response-content-disposition"] = str(self.content_disposition)
        if self.content_encoding is not None:
            outPutMap["response-content-encoding"] = str(self.content_encoding)
        if self.content_language is not None:
            outPutMap["response-content-language"] = str(self.content_language)
        if self.content_type is not None:
            outPutMap["response-content-type"] = str(self.content_type)
        if self.expires is not None:
            outPutMap["response-expires"] = str(self.expires)
        if self.versionId is not None:
            outPutMap["versionId"] = str(self.versionId)
        return outPutMap
        
#coding=utf-8

from com.obs.models.expiration import Expiration
from com.obs.models.date_time import DateTime

class Rule(object):
    '''
    classdocs
    '''
    

    def __init__(self,id = None,prefix = None,status = None, expiration = Expiration()):
        '''
        Constructor
        '''
        self.id = id
        self.prefix = prefix
        self.status = status
        self.expiration = expiration
    
    def to_xml(self):
        xml_list = []
        xml_list.append('<Rule>')
        if self.id is not None:
            id = '<ID>' + self.id + '</ID>'
            xml_list.append(id)
        if self.prefix is not None:
            prefix = '<Prefix>' + self.prefix + '</Prefix>'
            xml_list.append(prefix)
        if self.status is not None:
            status = '<Status>' +self.status + '</Status>'
            xml_list.append(status)
        if self.expiration is not None:
            if self.expiration.date is not None or self.expiration.days is not None:
                xml_list.append('<Expiration>')
                if self.expiration.date is not None:
                    if isinstance(self.expiration.date,(DateTime)):
                        self.expiration.date = self.expiration.date.ToUTTime()
                    date  = '<Date>' +  str(self.expiration.date) + '</Date>'
                    xml_list.append(date)
                
                if self.expiration.days is not None:               
                    days = '<Days>' + str(self.expiration.days) + '</Days>'
                    xml_list.append(days)
                xml_list.append('</Expiration>')
        xml_list.append('</Rule>') 
        
        s = ''.join(item for item in xml_list)  
        
        return s

#coding=utf-8

from com.obs.models.condition import Condition
from com.obs.models.redirect import Redirect

class RoutingRule(object):
    '''
    classdocs
    '''


    def __init__(self, condition = Condition(),redirect = Redirect()):
        '''
        Constructor
        '''
        self.condition = condition
        self.redirect = redirect
    def to_xml(self):
        return self.condition.to_xml() + self.redirect.to_xml()
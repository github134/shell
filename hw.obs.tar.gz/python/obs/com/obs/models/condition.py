#coding=utf-8

class Condition(object):
    '''
    classdocs
    '''


    def __init__(self, KeyPrefixEquals=None,HttpErrorCodeReturnedEquals=None):
        '''
        Constructor
        '''
        self.keyPrefixEquals = KeyPrefixEquals
        self.httpErrorCodeReturnedEquals = HttpErrorCodeReturnedEquals
    def to_xml(self):
        xml = ''
        if self.keyPrefixEquals is None and self.httpErrorCodeReturnedEquals is None:
            return xml
        xml += '<Condition>'
        if self.keyPrefixEquals is not None :
            xml += '<KeyPrefixEquals>' + self.keyPrefixEquals + '</KeyPrefixEquals>'
        if self.httpErrorCodeReturnedEquals is not None :
            xml += '<HttpErrorCodeReturnedEquals>' + str(self.httpErrorCodeReturnedEquals) + '</HttpErrorCodeReturnedEquals>' 
        xml += '</Condition>'
        return xml

#coding=utf-8

import os, sys
import xml.etree.ElementTree as ET
from com.obs.models.grant import Grant
from com.obs.models.grantee import Grantee
from com.obs.response.nameSpace import NameSpace

class Logging(object):
    '''
    classdocs
    '''


    def __init__(self,targetBucket=None,targetPrefix=None,targetGrants= None):
        '''
        Constructor
        '''
        self.targetBucket = targetBucket
        self.targetPrefix = targetPrefix
        self.targetGrants = targetGrants

    def to_xml(self):
        xml_list = []
        xml_list.append('''<?xml version="1.0" encoding="UTF-8"?>''')
        xml_list.append('''<BucketLoggingStatus  xmlns="http://doc.s3.amazonaws.com/2006-03-01/">''')
        if self.targetBucket is None and self.targetPrefix is None and (self.targetGrants is None or len(self.targetGrants)==0):
            xml_list.append('</BucketLoggingStatus>')
            return self.write_xml(xml_list)
        
        xml_list.append('<LoggingEnabled>')
        if self.targetBucket is not None:
            xml_backet = '<TargetBucket>' + self.targetBucket + '</TargetBucket>'
            xml_list.append(xml_backet)
        if self.targetPrefix is not None:
            xml_prefix = '<TargetPrefix>' + self.targetPrefix + '</TargetPrefix>'
            xml_list.append(xml_prefix)
        if self.targetGrants is not None:
            xml_list.append('<TargetGrants>')
            for grant in self.targetGrants:
                xml_list.append('<Grant>')
                if grant.grantee is not None:
                    xml_list.append(grant.grantee.to_xml())
                if grant.permission is not None:
                    permission = '<Permission>' + grant.permission + '</Permission>'
                    xml_list.append(permission)
                xml_list.append('</Grant>')
            xml_list.append('</TargetGrants>')
        xml_list.append('</LoggingEnabled>')
        xml_list.append('</BucketLoggingStatus>')
        
        return self.write_xml(xml_list)
    
    def write_xml(self,xml_list):
        s = ''.join(item for item in xml_list)
        path = os.path.abspath(os.path.dirname(sys.argv[0]))
        with open(path + "\\logging.xml", 'wb') as f:
            f.write(s)
        return path + "\\logging.xml"  #返回文件的路径名
        
    @staticmethod
    def parse_xml(xml):
        bucket = logStatus.parse_targetBucket(xml)
        prefix = logStatus.parse_targetPrefix(xml)
        grants = logStatus.parse_grant(xml)
        if (bucket is None and prefix is None and grants is None):
            return None
        return Logging(bucket,prefix,grants)
        
    
class logStatus:
    
    ns = '{http://www.w3.org/2001/XMLSchema-instance}'
    NS = NameSpace.getNameSpace()
    
    @staticmethod
    def parse_targetBucket(xml):
        logStatus.NS = NameSpace.getNameSpace()
        if xml is None:
            return None
        root = ET.fromstring(xml)
        TargetBucket = root.find(".//{0}TargetBucket".format(logStatus.NS))
        return TargetBucket.text if TargetBucket is not None else None
     
    @staticmethod 
    def  parse_targetPrefix(xml): 
        logStatus.NS = NameSpace.getNameSpace()
        if xml is None:
            return None
        root = ET.fromstring(xml)
        TargetPrefix = root.find(".//{0}TargetPrefix".format(logStatus.NS))
        return  TargetPrefix.text if TargetPrefix is not None else None  
        
    @staticmethod
    def  parse_grant(xml): 
        logStatus.NS = NameSpace.getNameSpace()
        if xml is None:
            return None
        root = ET.fromstring(xml) 
        grants = root.findall('.//{0}TargetGrants/{0}Grant'.format(logStatus.NS))
        if len(grants)==0:
            return None
        grantlist = []
        for grant in grants:
            grantee = ''
            if grant.find('./{0}Grantee'.format(logStatus.NS)).attrib.get('{0}type'.format(logStatus.ns)) == "Group":
                group1 = grant.find('./{0}Grantee/{0}URI'.format(logStatus.NS)).text
                group1 =  group1[group1.rfind("/") + 1:]
                grantee = Grantee(group=group1)                                          
            elif grant.find('./{0}Grantee'.format(logStatus.NS)).attrib.get('{0}type'.format(logStatus.ns)) == "CanonicalUser":
                owner_id = grant.find('./{0}Grantee/{0}ID'.format(logStatus.NS)).text
                owner_name = grant.find('./{0}Grantee/{0}DisplayName'.format(logStatus.NS)).text
                grantee = Grantee(owner_id, owner_name)
            per =  grant.find('./{0}Permission'.format(logStatus.NS))
            per = per.text if per is not None else None
            grantelem = Grant(grantee,per)
            grantlist.append(grantelem) 
            
        return grantlist    
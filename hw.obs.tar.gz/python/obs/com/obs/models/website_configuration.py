#coding=utf-8

import os, sys
from com.obs.models.index_document import IndexDocument
from com.obs.models.error_document import ErrorDocument
from com.obs.models.redirect_all_request_to import RedirectAllRequestTo

class WebsiteConfiguration(object):
    '''
    classdocs
    '''


    def __init__(self, redirectAllRequestTo=RedirectAllRequestTo(),
                 indexDocument=IndexDocument(),
                 errorDocument=ErrorDocument(),
                 routingRules=None
                 ):
        '''
        Constructor
        '''
        self.redirectAllRequestTo = redirectAllRequestTo
        self.indexDocument = indexDocument
        self.errorDocument = errorDocument
        self.routingRules = routingRules  # RoutingRule的链表
    def to_xml(self):
        xml_list = []
        xml_list.append('<WebsiteConfiguration xmlns="http://s3.amazonaws.com/doc/2006-03-01/">')
        if self.redirectAllRequestTo is not None:
            xml_list.append(self.redirectAllRequestTo.to_xml()) 
        if self.indexDocument is not None:
            xml_list.append(self.indexDocument.to_xml())  
        if self.errorDocument is not None:
            xml_list.append(self.errorDocument.to_xml()) 
        if self.routingRules is not None and len(self.routingRules) != 0:
            xml_list.append('<RoutingRules>')
            for routingRule in self.routingRules:
                xml_list.append('<RoutingRule>')
                xml_list.append(routingRule.to_xml())
                xml_list.append('</RoutingRule>')
            xml_list.append('</RoutingRules>')
        xml_list.append('</WebsiteConfiguration>')
        s = ''.join(item for item in xml_list)
        path = os.path.abspath(os.path.dirname(sys.argv[0]))
        with open(path + "\\website.xml", 'wb') as f:
            f.write(s)  
        return path + "\\website.xml"  # 返回文件的路径名

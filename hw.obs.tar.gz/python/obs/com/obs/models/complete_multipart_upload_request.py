#coding=utf-8

import os, sys

class CompletePart(object):
    #===============================================================================
    # 段信息。
    #===============================================================================
    partNum = None
    #===============================================================================
    # 段号。
    #===============================================================================
    etag = None
    #===============================================================================
    # 对应段的ETag值。
    #===============================================================================
    
    def __init__(self, partNum=None, etag=None):
        self.partNum = partNum
        self.etag = etag

class CompleteMultipartUploadRequest(object):
    #===============================================================================
    # 合并段请求。
    #===============================================================================
    
    parts = [CompletePart()]
    #===============================================================================
    # 段列表。
    #===============================================================================

    def __init__(self, parts=None):
        self.parts = parts
    
    def add_part(self, part):
        self.parts.append(part)  
        
    #===========================================================================
    # 将访问控制列表转换为xml字符串  保存到文件中
    # @return String 返回文件的路径
    #===========================================================================
    def to_xml(self):
        
        if not self.parts: 
            raise Exception("Invalid AccessControlList: missing Part")

        str_list = []
        str_list.append("<CompleteMultipartUpload>")
        for obj in self.parts:
            str_list.append("<Part><PartNumber>" + str(obj.partNum) + "</PartNumber>")
            str_list.append("<ETag>" + str(obj.etag) + "</ETag></Part>")
        
        str_list.append("</CompleteMultipartUpload>")
        
        s = ''.join(item for item in str_list)
       
        path = os.path.abspath(os.path.dirname(sys.argv[0]))
        file_path = os.path.join(path, "complete_multipart_upload_request.xml")
        with open(file_path, 'wb') as f:
            f.write(s)
        return file_path  # 返回文件的路径名
        


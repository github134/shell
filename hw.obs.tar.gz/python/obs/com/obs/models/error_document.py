#coding=utf-8

class ErrorDocument(object):
    '''
    classdocs
    '''


    def __init__(self, Key=None):
        '''
        Constructor
        '''
        self.key = Key
    def to_xml(self):
        xml = ''
        if self.key is not None:
            xml =  '<ErrorDocument>' + '<Key>' + str(self.key) + '</Key>' + '</ErrorDocument>'
        return xml
        
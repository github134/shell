#coding=utf-8

import os
import sys
import json

class Policy(object):
    '''
    classdocs
    '''


    def __init__(self, policyJSON=None):
        '''
        Constructor
        '''
        self.policyJSON = policyJSON
    
    def to_json(self):
        if self.policyJSON:
            path = os.path.abspath(os.path.dirname(sys.argv[0]))
            with open(path + "\\policy.txt", 'wb') as f:
                f.write(str(self.policyJSON))
    
            return path + "\\policy.txt"  
    
    @staticmethod 
    def parse_xml(strJson):
    #将json格式的字符串装成字典
        if strJson is not None:
            if strJson[:1] == '<':
                return strJson
            return json.loads(strJson)
    
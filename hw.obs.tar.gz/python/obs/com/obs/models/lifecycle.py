#coding=utf-8

import os, sys

class Lifecycle(object):
    '''
    classdocs
    '''
    

    def __init__(self, rule=None):
        '''
        Constructor
        '''
        self.rule = rule
    
    def to_xml(self):
        xml_list = []
        xml_list.append('<LifecycleConfiguration>')
        for item in self.rule:
            s = item.to_xml()
            xml_list.append(s)
        xml_list.append('</LifecycleConfiguration>')
        
        s = ''.join(item for item in xml_list) 
        path = os.path.abspath(os.path.dirname(sys.argv[0]))
        with open(path + "\\lifecyc.xml", 'wb') as f:
            f.write(s)
    
        return path + "\\lifecyc.xml"
        
    

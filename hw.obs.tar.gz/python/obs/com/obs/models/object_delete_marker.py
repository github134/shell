#coding=utf-8

from com.obs.models.owner import Owner

class ObjectDeleteMarker(object):
    '''
    classdocs
    '''

    def __init__(self, key = None,
                    versionId = None,
                    isLatest = None,
                    lastModified = None,
                    owner = Owner()
                    ):
        '''
        Constructor
        '''
        self.key = key
        self.versionId = versionId
        self.isLatest = isLatest
        self.lastModified = lastModified
        self.owner = owner
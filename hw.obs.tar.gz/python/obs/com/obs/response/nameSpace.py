#coding=utf-8

NS = ['{http://obs.myhwclouds.com/doc/2015-06-30/}','{http://s3.amazonaws.com/doc/2006-03-01/}','{http://obs.example.com/doc/2015-06-30/}']

class NameSpace(object):

    mNs  = ''
    
    @staticmethod
    def setNameSpace(nameSpace):
        NameSpace.mNs = nameSpace
    
    @staticmethod
    def getNameSpace():
        return NameSpace.mNs
    
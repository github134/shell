#coding=utf-8

import xml.etree.ElementTree as ET
from com.obs.response.nameSpace  import NameSpace

class CopyPartResponse(object):
    #===========================================================================
    # 复制段返回信息
    #===========================================================================
    def __init__(self, lastModified, eTag):
        
        self.modifiedDate = lastModified
        self.etagValue = eTag
    
    #===========================================================================
    # 定义静态方法，用来解析xml，最后返回CopyPartResponse对象
    #===========================================================================
    @staticmethod    
    def parse_xml(xml):
        if xml is not None:
            return CopyPart().parse_result(xml)
        
class CopyPart:
    
    def __init__(self):
        pass
    
    #===========================================================================
    # 获取Result相关信息
    #===========================================================================
    @staticmethod
    def parse_result(xml):  
        NS = NameSpace.getNameSpace()      
        root = ET.fromstring(xml)
        lastModified = root.find('.//{0}LastModified'.format(NS)).text      
        eTag = root.find('.//{0}ETag'.format(NS)).text      
        return CopyPartResponse(lastModified, eTag)  # 返回CopyPartResponse的对象   

#coding=utf-8

import xml.etree.ElementTree as ET
from com.obs.response.nameSpace  import NameSpace

class GetBucketQuotaResponse(object):
    #===========================================================================
    # 获取桶配额返回信息
    #===========================================================================
    def __init__(self, quota):
        
        self.quota = quota
    
    #===========================================================================
    # 定义静态方法，用来解析xml，最后返回GetBucketQuotaResponse对象
    #===========================================================================
    @staticmethod    
    def parse_xml(xml):
        if xml is not None:
            return GetBucketQuota().parse_result(xml)
        
class GetBucketQuota:
    
    def __init__(self):
        self.quota = ""  # Quota对象
    
    #===========================================================================
    # 获取Result相关信息
    #===========================================================================
    @staticmethod
    def parse_result(xml):  
        NS = NameSpace.getNameSpace()     
        root = ET.fromstring(xml)
        quota = root.find('.//{0}StorageQuota'.format(NS)).text      
        return GetBucketQuotaResponse(quota)  # 返回GetBucketQuotaResponse的对象   

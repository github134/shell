#coding=utf-8

import xml.etree.ElementTree as ET
from com.obs.models.initiator import Initiator 
from com.obs.models.owner import Owner
from com.obs.response.nameSpace import NameSpace

class Part(object):
    def __init__(self, partnumber=None, modifieddate=None, etag=None, size=None):
        self.partNumber = partnumber
        self.lastModified = modifieddate
        self.etag = etag
        self.size = size

class ListPartsResponse(object):
    #===========================================================================
    # 列出段返回信息
    #===========================================================================
    def __init__(self, bucketName=None, objectKey=None, uploadId=None, initiator=Initiator(), owner=Owner(), standard=None, partNmebermarker=None, nextPartNumberMarker=None, maxParts=None, isTruncated=None, parts=None):
        self.bucketName = bucketName
        self.objectKey = objectKey
        self.uploadId = uploadId
        self.initiator = initiator
        self.owner = owner
        self.standard = standard
        self.partNmebermarker = partNmebermarker
        self.nextPartNumberMarker = nextPartNumberMarker
        self.maxParts = maxParts
        self.isTruncated = isTruncated
        self.parts = parts
    
    #===========================================================================
    # 定义静态方法，用来解析xml，最后返回ListPartsResponse对象
    #===========================================================================
    @staticmethod    
    def parse_xml(xml):
        if xml is not None:
            return ListParts().parse_result(xml)
        
class ListParts:
    
    NS = NameSpace.getNameSpace()
    def __init__(self):
        pass
    #===========================================================================
    # 获取Result相关信息
    #===========================================================================
    @staticmethod
    def parse_result(xml):  
        ListParts.NS = NameSpace.getNameSpace()     
        root = ET.fromstring(xml)
        
        bucketName = root.find('.//{0}Bucket'.format(ListParts.NS)).text      
        objectKey = root.find('.//{0}Key'.format(ListParts.NS)).text      
        uploadId = root.find('.//{0}UploadId'.format(ListParts.NS)).text 
             
        standard = root.find('.//{0}StorageClass'.format(ListParts.NS)).text      
        partNmebermarker = root.find('.//{0}PartNumberMarker'.format(ListParts.NS)).text      
        nextPartNumberMarker = root.find('.//{0}NextPartNumberMarker'.format(ListParts.NS)).text      
        maxParts = root.find('.//{0}MaxParts'.format(ListParts.NS)).text      
        isTruncated = root.find('.//{0}IsTruncated'.format(ListParts.NS)).text 
        
        initiatorid = root.find('.//{0}Initiator/{0}ID'.format(ListParts.NS)).text      
        displayname = root.find('.//{0}Initiator/{0}DisplayName'.format(ListParts.NS)).text      
        
        initiator = Initiator(initiatorid, displayname)
        
        ownerid = root.find('.//{0}Owner/{0}ID'.format(ListParts.NS)).text      
        ownername = root.find('.//{0}Owner/{0}DisplayName'.format(ListParts.NS)).text      
        
        owner = Owner(ownerid, ownername)
        
        part_list = root.findall('./{0}Part'.format(ListParts.NS))
        parts = []
        if part_list:
            for part in part_list:
                partnumber = part.find('./{0}PartNumber'.format(ListParts.NS)).text
                modifieddate = part.find('./{0}LastModified'.format(ListParts.NS)).text
                etag = part.find('./{0}ETag'.format(ListParts.NS)).text
                size = part.find('./{0}Size'.format(ListParts.NS)).text
                __part = Part(partnumber, modifieddate, etag, size)
                parts.append(__part)
                
        return ListPartsResponse(bucketName, objectKey, uploadId, initiator, owner, standard, partNmebermarker, nextPartNumberMarker, maxParts, isTruncated, parts)  # 返回ListPartsResponse的对象   


#coding=utf-8

import xml.etree.ElementTree as ET
from com.obs.models.upload import Upload
from com.obs.models.initiator import Initiator
from com.obs.models.owner import Owner
from com.obs.models.common_prefix import CommonPrefix
from com.obs.response.nameSpace import NameSpace

class ListMultipartUploadsResponse(object):
    '''
    classdocs
    '''


    def __init__(self,bucket=None,
                 keyMarker=None,
                 uploadIdMarker=None,
                 nextKeyMarker=None,
                 nextUploadIdMarker=None,
                 maxUploads=None,
                 isTruncated=None,
                 prefix = None,
                 delimiter = None,
                 upload=Upload(),
                 commonPrefixs = CommonPrefix()):
        '''
        Constructor
        '''
        self.bucket = bucket
        self.keyMarker = keyMarker
        self.uploadIdMarker = uploadIdMarker
        self.nextKeyMarker = nextKeyMarker
        self.nextUploadIdMarker = nextUploadIdMarker
        self.maxUploads = maxUploads
        self.isTruncated = isTruncated
        self.prefix = prefix
        self.delimiter = delimiter
        self.upload = upload
        self.commonPrefixs = commonPrefixs
    
    @staticmethod
    def parse_xml(xml):
        NS = NameSpace.getNameSpace()
        if not xml:
            return None
        root = ET.fromstring(xml)
        
        Bucket = root.find("./{0}Bucket".format(NS)).text
        KeyMarker = root.find("./{0}KeyMarker".format(NS))
        KeyMarker = KeyMarker.text if KeyMarker is not None else None
        
        UploadIdMarker = root.find("./{0}UploadIdMarker".format(NS))
        UploadIdMarker = UploadIdMarker.text if UploadIdMarker is not None else None
        NextKeyMarker = root.find("./{0}NextKeyMarker".format(NS))
        NextKeyMarker = NextKeyMarker.text if NextKeyMarker is not None else None
        NextUploadIdMarker = root.find("./{0}NextUploadIdMarker".format(NS))
        NextUploadIdMarker = NextUploadIdMarker.text if NextUploadIdMarker is not None else None
    
        MaxUploads = root.find("./{0}MaxUploads".format(NS))
        MaxUploads = MaxUploads.text if MaxUploads is not None else None
        
        IsTruncated = root.find("./{0}IsTruncated".format(NS))
        IsTruncated = IsTruncated.text if IsTruncated is not None else None
        
        Prefix = root.find("./{0}Prefix".format(NS))
        prefix = Prefix.text if Prefix is not None else None
        delimiter = root.find("./{0}Delimiter".format(NS))
        delimiter = delimiter.text if delimiter is not None else None
        
        rules = root.findall('./{0}Upload'.format(NS)) 
        uploadlist = None
        if rules:
            uploadlist = []
            for rule in rules:
                Key = rule.find("./{0}Key".format(NS))
                Key = Key.text if Key is not None else None
                UploadId = rule.find("./{0}UploadId".format(NS))
                UploadId = UploadId.text if UploadId is not None else None
                
                ID = rule.find("./{0}Initiator/{0}ID".format(NS))
                ID = ID.text if ID is not None else None
                
                DisplayName = rule.find('./{0}Initiator/{0}DisplayName'.format(NS)) 
                DisplayName = DisplayName.text if DisplayName is not None else None
                initiator = Initiator(ID,DisplayName)
                
                ower_id = rule.find("./{0}Owner/{0}ID".format(NS))
                ower_id = ower_id.text if ower_id is not None else None  
                ower_name = rule.find("./{0}Owner/{0}DisplayName".format(NS)) 
                ower_name = ower_name.text if ower_name is not None else None
                ower = Owner(ower_id,ower_name)
                
                StorageClass = rule.find("./{0}StorageClass".format(NS))
                StorageClass = StorageClass.text if StorageClass is not None else None
                
                Initiated = rule.find("./{0}Initiated".format(NS))
                Initiated = Initiated.text if Initiated is not None else None
                upload = Upload(Key,UploadId,initiator,ower,StorageClass,Initiated)
                uploadlist.append(upload)
        common = root.findall('./{0}CommonPrefixes'.format(NS))
        commonlist = None
        if common:
            commonlist = []
            for comm in common:
                comm_prefix = comm.find("./{0}Prefix".format(NS))
                comm_prefix = comm_prefix.text if comm_prefix is not None else None
                Comm_Prefix = CommonPrefix(comm_prefix) 
                commonlist.append(Comm_Prefix) 
        
        return ListMultipartUploadsResponse(Bucket,KeyMarker,UploadIdMarker,
                                          NextKeyMarker,NextUploadIdMarker,MaxUploads,
                                          IsTruncated,prefix,delimiter,uploadlist,commonlist)

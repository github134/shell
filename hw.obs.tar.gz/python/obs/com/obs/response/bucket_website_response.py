#coding=utf-8

import xml.etree.ElementTree as ET

from com.obs.models.index_document import IndexDocument
from com.obs.models.error_document import ErrorDocument
from com.obs.models.routing_rule import RoutingRule
from com.obs.models.condition import Condition
from com.obs.models.redirect import Redirect
from com.obs.models.redirect_all_request_to import RedirectAllRequestTo
from com.obs.response.nameSpace import NameSpace

class BucketWebsite(object):
    '''
    classdocs
    '''


    def __init__(self,redirectAllRequestTo=RedirectAllRequestTo(),
                 indexDocument = IndexDocument(),
                 errorDocument = ErrorDocument(),
                 routingRules = None):
        '''
        Constructor
        '''
        self.redirectAllRequestTo = redirectAllRequestTo
        self.indexDocument = indexDocument
        self.errorDocument = errorDocument
        self.routingRules = routingRules
    
 
    @staticmethod
    def parse_xml(xml):  
        redirect = ParseWeb.parse_RequestTo(xml)
        index = ParseWeb.parse_index(xml)
        error = ParseWeb.parse_error(xml)
        routs = ParseWeb.parse_Rules(xml)
        if (redirect is None and index is None and error is None and routs is None):
            return None
        return BucketWebsite(redirect,index,error,routs)


class ParseWeb():
    
    NS = NameSpace.getNameSpace()
    
    @staticmethod
    def parse_RequestTo(xml):
        ParseWeb.NS = NameSpace.getNameSpace()
        root = ET.fromstring(xml)
        redirectAllRequestTo = root.find("./{0}RedirectAllRequestsTo".format(ParseWeb.NS))
        if redirectAllRequestTo is not None: 
            hostname = root.find(".//{0}HostName".format(ParseWeb.NS))
            hostname =  hostname.text if hostname is not None else None
            protocol = root.find(".//{0}Protocol".format(ParseWeb.NS))
            protocol =  protocol.text if protocol is not None else None
            if (hostname is not None and protocol is not None):
                return RedirectAllRequestTo(hostname,protocol)
        else:
            return None
        
    @staticmethod
    def parse_index(xml):
        ParseWeb.NS = NameSpace.getNameSpace()
        root = ET.fromstring(xml)
        indexDocument = root.find("./{0}IndexDocument".format(ParseWeb.NS))
        if indexDocument is not None:
            Suffix = root.find(".//{0}Suffix".format(ParseWeb.NS))
            Suffix =  Suffix.text if Suffix is not None else None
            if (Suffix is not None):
                return IndexDocument(Suffix)
        else:
            return None
    
    
    @staticmethod
    def parse_error(xml):
        ParseWeb.NS = NameSpace.getNameSpace()
        root = ET.fromstring(xml)
        errorDocument = root.find("./{0}ErrorDocument".format(ParseWeb.NS))
        if errorDocument is not None:
            Key = root.find(".//{0}Key".format(ParseWeb.NS)) 
            Key =  Key.text if Key is not None else None
            if Key is not None:
                return ErrorDocument(Key)
        else:
            return None
        
    @staticmethod   
    def parse_Rules(xml):
        ParseWeb.NS = NameSpace.getNameSpace()
        root = ET.fromstring(xml)
        routingRules = root.findall("./{0}RoutingRules/{0}RoutingRule".format(ParseWeb.NS))
        if routingRules is not None and len(routingRules) != 0:
            routingRule_list = []
            for rout in routingRules:
                KeyPrefixEquals =  rout.find(".//{0}Condition/{0}KeyPrefixEquals".format(ParseWeb.NS))
                KeyPrefixEquals =  KeyPrefixEquals.text if KeyPrefixEquals is not None else None
                HttpErrorCodeReturnedEquals =  rout.find(".//{0}Condition/{0}HttpErrorCodeReturnedEquals".format(ParseWeb.NS))
                HttpErrorCodeReturnedEquals =  HttpErrorCodeReturnedEquals.text if HttpErrorCodeReturnedEquals is not None else None
               
                condition = Condition(KeyPrefixEquals,HttpErrorCodeReturnedEquals)

                Protocol =  rout.find(".//{0}Redirect/{0}Protocol".format(ParseWeb.NS))
                Protocol =  Protocol.text if Protocol is not None else None
                HostName =  rout.find(".//{0}Redirect/{0}HostName".format(ParseWeb.NS))
                HostName =  HostName.text if HostName is not None else None
                ReplaceKeyPrefixWith =  rout.find(".//{0}Redirect/{0}ReplaceKeyPrefixWith".format(ParseWeb.NS))
                ReplaceKeyPrefixWith =  ReplaceKeyPrefixWith.text if ReplaceKeyPrefixWith is not None else None
                ReplaceKeyWith =  rout.find(".//{0}Redirect/{0}ReplaceKeyWith".format(ParseWeb.NS))
                ReplaceKeyWith =  ReplaceKeyWith.text if ReplaceKeyWith is not None else None
                HttpRedirectCode =  rout.find(".//{0}Redirect/{0}HttpRedirectCode".format(ParseWeb.NS))
                HttpRedirectCode =  HttpRedirectCode.text if HttpRedirectCode is not None else None
                
                redirect = Redirect(Protocol,HostName,ReplaceKeyPrefixWith,ReplaceKeyWith,HttpRedirectCode)
                routingRule = RoutingRule(condition,redirect)
                
                routingRule_list.append(routingRule)
            
            return routingRule_list
      
        else:
            return None

        
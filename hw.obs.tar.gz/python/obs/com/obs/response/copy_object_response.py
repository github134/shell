#coding=utf-8

import xml.etree.ElementTree as ET
from com.obs.response.nameSpace  import NameSpace

class CopyObjectResponse(object):
    #===========================================================================
    # 复制对象返回信息。
    #===========================================================================
    def __init__(self, lastModified, eTag):
        
        self.lastModified = lastModified
        self.eTag = eTag
    
    #===========================================================================
    # 定义静态方法，用来解析xml，最后返回CopyObjectResponse对象。
    #===========================================================================
    @staticmethod    
    def parse_xml(xml):
        if xml is not None:
            return CopyObject().parse_result(xml)
        
class CopyObject:
    
    NS = NameSpace.getNameSpace()
    
    def __init__(self):
        pass
    
    #===========================================================================
    # 获取Result相关信息。
    #===========================================================================
    @staticmethod
    def parse_result(xml):  
        CopyObject.NS = NameSpace.getNameSpace()     
        root = ET.fromstring(xml)
        lastModified = root.find('.//{0}LastModified'.format(CopyObject.NS)).text      
        eTag = root.find('.//{0}ETag'.format(CopyObject.NS)).text      
        return CopyObjectResponse(lastModified, eTag)  # 返回CopyObjectResponse的对象   

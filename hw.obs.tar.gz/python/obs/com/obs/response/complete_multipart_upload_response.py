#coding=utf-8

import xml.etree.ElementTree as ET
from com.obs.response.nameSpace import NameSpace

class CompleteMultipartUploadResponse(object):
    
    #===============================================================================
    # 合并段返回信息。
    #===============================================================================
    def __init__(self, location, bucket, key, eTag):
        
        self.location = location  # 合并后得到的对象的url。
        self.bucket = bucket  # 合并段所在的桶。
        self.key = key  # 合并得到对象的key。
        self.eTag = eTag  # 根据各个段的ETag计算得出的结果。
    
    #===========================================================================
    # 定义静态方法，用来解析xml，最后返回CompleteMultipartUploadResponse对象
    #===========================================================================
    @staticmethod    
    def parse_xml(xml):
        if xml is not None:
            return CompleteMultipartUpload().parse_result(xml)
        
class CompleteMultipartUpload:
    
    NS = NameSpace.getNameSpace()
    
    def __init__(self):
        pass
    
    #===========================================================================
    # 获取Result相关信息
    #===========================================================================
    @staticmethod
    def parse_result(xml): 
        CompleteMultipartUpload.NS = NameSpace.getNameSpace()  
        root = ET.fromstring(xml)
        location = root.find('.//{0}Location'.format(CompleteMultipartUpload.NS)).text      
        bucket = root.find('.//{0}Bucket'.format(CompleteMultipartUpload.NS)).text      
        key = root.find('.//{0}Key'.format(CompleteMultipartUpload.NS)).text      
        eTag = root.find('.//{0}ETag'.format(CompleteMultipartUpload.NS)).text      
        return CompleteMultipartUploadResponse(location, bucket, key, eTag)  # 返回CompleteMultipartUploadResponse的对象   

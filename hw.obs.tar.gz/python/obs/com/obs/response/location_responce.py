#coding=utf-8

import xml.etree.ElementTree as ET
from com.obs.response.nameSpace import NameSpace

class LocationResponce(object):
    '''
    classdocs
    '''
    def __init__(self,location=None):
        self.location = location
    
    @staticmethod
    def parse_xml(xml):
        NS = NameSpace.getNameSpace()
        if xml:
            root = ET.fromstring(xml)
            location = root.find("./{0}LocationConstraint".format(NS))
            location = location.text if location is not None else None 
            if location is None:
                return None
            return LocationResponce(location)

#coding=utf-8

import xml.etree.ElementTree as ET
from com.obs.response.nameSpace  import NameSpace

class DeleteObjectsResponse(object):
    #===========================================================================
    # 获取桶的复制策略返回信息
    #===========================================================================
    def __init__(self, deleted_list, error_list):
        
        self.deleted = deleted_list
        self.error = error_list
    
    #===========================================================================
    # 定义静态方法，用来解析xml，最后返回DeleteObjectsResponse对象
    #===========================================================================
    @staticmethod    
    def parse_xml(xml):
        if xml is not None:
            return DeletedObjects().parse_result(xml)
        
class DeletedObjects:
    
    NS = NameSpace.getNameSpace()
    def __init__(self):
        pass
    #===========================================================================
    # 获取Result相关信息
    #===========================================================================
    @staticmethod
    def parse_result(xml):  
        DeletedObjects.NS = NameSpace.getNameSpace()   
        root = ET.fromstring(xml)
        deleted_list = []
        error_list = []
        deleteds = root.findall('./{0}Deleted'.format(DeletedObjects.NS))
        for d in deleteds:
            key = d.find('./{0}Key'.format(DeletedObjects.NS))
            key =  key.text if key is not None else None
            deleteMarker = d.find('./{0}DeleteMarker'.format(DeletedObjects.NS))
            deleteMarker =  deleteMarker.text if deleteMarker is not None else None
            deleteMarkerVersionId = d.find('./{0}DeleteMarkerVersionId'.format(DeletedObjects.NS))
            deleteMarkerVersionId =  deleteMarkerVersionId.text if deleteMarkerVersionId is not None else None
            dl = DeleteObjectResult(key, deleteMarker, deleteMarkerVersionId)
            deleted_list.append(dl)
        errors = root.findall('./{0}Error'.format(DeletedObjects.NS))
        if errors:
            for e in errors:
                _key = e.find('./{0}Key'.format(DeletedObjects.NS))
                _key =  _key.text if _key is not None else None
                _code = e.find('./{0}Code'.format(DeletedObjects.NS))
                _code =  _code.text if _code is not None else None
                _message = e.find('./{0}Message'.format(DeletedObjects.NS))
                _message =  _message.text if _message is not None else None
                el = ErrorResult(_key, _code, _message)
                error_list.append(el)
        result = DeleteObjectsResponse(deleted_list, error_list)
        return result
        
    
class ErrorResult(object):
    '''
    #批量删除对象返回的错误信息
    '''
    def __init__(self, key=None, code=None, message=None):
        self.key = key  # 每个删除结果的对象名。
        self.code = code  # 删除失败结果的错误码。
        self.message = message  # 删除失败结果的错误消息。
        
class DeleteObjectResult(object):
    '''
    #批量删除对象返回的成功信息
    '''
    def __init__(self, key=None, deleteMarker=None, deleteMarkerVersionId=None):
        
        self.key = key  # 每个删除结果的对象名。
        self.deleteMarker = deleteMarker
        self.deleteMarkerVersionId = deleteMarkerVersionId

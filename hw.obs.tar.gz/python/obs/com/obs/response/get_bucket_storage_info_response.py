#coding=utf-8

import xml.etree.ElementTree as ET
from com.obs.response.nameSpace  import NameSpace

class GetBucketStorageInfoResponse(object):
    #===========================================================================
    # 获取桶存量返回信息
    #===========================================================================
    def __init__(self, size, object_number):
        
        self.size = size
        self.objectNumber = object_number
    
    #===========================================================================
    # 定义静态方法，用来解析xml，最后返回GetBucketStorageInfoResponse对象
    #===========================================================================
    @staticmethod    
    def parse_xml(xml):
        if xml is not None:
            return GetBucketStorageInfo().parse_result(xml)
        
class GetBucketStorageInfo:
    
    def __init__(self):
        self.size = ""  # Size对象
        self.object_number = ""  # ObjectNumber对象
    
    #===========================================================================
    # 获取Result相关信息
    #===========================================================================
    @staticmethod
    def parse_result(xml): 
        NS =  NameSpace.getNameSpace()      
        root = ET.fromstring(xml)
        size = root.find('.//{0}Size'.format(NS)).text      
        object_number = root.find('.//{0}ObjectNumber'.format(NS)).text 
        return GetBucketStorageInfoResponse(size, object_number)  # 返回GetBucketStorageInfoResponse的对象   

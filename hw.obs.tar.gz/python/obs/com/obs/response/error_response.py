#coding=utf-8

import os
from com.obs.response.get_result import GetResult
from com.obs.log.Log import LOG, ERROR
from com.obs.utils.utils import Utils

class ErrorMsg(object):
    '''
    classdocs
    '''


    def __init__(self):
        '''
        Constructor
        '''
        
        pass
    

    flag = -1
    @staticmethod
    def is_obj_none(objName=None):
        if objName is None or len(objName) == 0:
            ErrorMsg.flag = 0
            return True
        else:
            return False 
    
    @staticmethod
    def is_file_not_exist(filePath=None):
        if filePath is None or len(filePath) == 0:
            ErrorMsg.flag = 1
            return True
        filePath = Utils.safe_trans_file_path(filePath)
        if not os.path.exists(filePath.decode('utf-8')):
            ErrorMsg.flag = 1
            return True
        return False
    
    @staticmethod
    def GetError():        
        status = 400
        reason = 'BadRequest'
        
        if ErrorMsg.flag == 0:
            code = 'MissingSecurityTarget'
            message = 'Target name is empty'
        else:
            code = 'TargetFileNotExist'
            message = 'Target File is not exist'
        body = None
        LOG(ERROR, 'request error:status:%d,reason:%s,code:%s,message:%s', status, reason, code, message)
        return GetResult(code, message, status, reason, body, None, None, None, None)
        
    @staticmethod
    def BodyAndFileExist():
        status = 400
        reason = 'BadRequest'
        code = 'BodyAndFileBothExist'
        message = "the input body and sourcefile exist at same time"
        LOG(ERROR, 'request error:status:%d,reason:%s,code:%s,message:%s', status, reason, code, message)
        return GetResult(code, message, status, reason, None, None, None, None, None)
        
        
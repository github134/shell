#coding=utf-8

import xml.etree.ElementTree as ET
from com.obs.models.object_version_head import ObjectVersionHead
from com.obs.models.object_version import ObjectVersion
from com.obs.models.object_delete_marker import ObjectDeleteMarker
from com.obs.models.common_prefix import CommonPrefix
from com.obs.models.owner import Owner
from com.obs.response.nameSpace import NameSpace

class ObjectVersions(object):
    '''
    classdocs
    '''


    def __init__(self, head=ObjectVersionHead(),version=ObjectVersion(),marker=ObjectDeleteMarker(),prefix=CommonPrefix()):
        '''
        Constructor
        '''
        self.head = head
        self.versions = version
        self.markers = marker
        self.commonPrefixs = prefix
    
    @staticmethod
    def parse_xml(xml):
        head = ParseXml.parse_head(xml)
        versions = ParseXml.parse_versions(xml)
        marker = ParseXml.parse_markers(xml)
        prefix = ParseXml.parse_commonPrefixs(xml)
        
        return ObjectVersions(head,versions,marker,prefix)

class ParseXml:

    NS = NameSpace.getNameSpace()
    
    @staticmethod
    def parse_head(xml):
        ParseXml.NS = NameSpace.getNameSpace()
        if xml is None:
            return None
        root = ET.fromstring(xml)
        
        Name = root.find("./{0}Name".format(ParseXml.NS)).text
#         Name =  Name.text if Name is not None else None        
        Prefix = root.find("./{0}Prefix".format(ParseXml.NS))
        Prefix =  Prefix.text if Prefix is not None else None
        KeyMarker = root.find("./{0}KeyMarker".format(ParseXml.NS))
        KeyMarker =  KeyMarker.text if KeyMarker is not None else None
        VersionIdMarker = root.find("./{0}VersionIdMarker".format(ParseXml.NS))
        VersionIdMarker =  VersionIdMarker.text if VersionIdMarker is not None else None
        NextKeyMarker = root.find("./{0}NextKeyMarker".format(ParseXml.NS))
        NextKeyMarker =  NextKeyMarker.text if NextKeyMarker is not None else None
        NextVersionIdMarker = root.find("./{0}NextVersionIdMarker".format(ParseXml.NS))
        NextVersionIdMarker =  NextVersionIdMarker.text if NextVersionIdMarker is not None else None
        MaxKeys = root.find("./{0}MaxKeys".format(ParseXml.NS))
        MaxKeys =  MaxKeys.text if MaxKeys is not None else None        
        IsTruncated = root.find("./{0}IsTruncated".format(ParseXml.NS))
        IsTruncated =  IsTruncated.text if IsTruncated is not None else None 
        
        return   ObjectVersionHead(Name,Prefix,KeyMarker,VersionIdMarker,NextKeyMarker,NextVersionIdMarker,MaxKeys,IsTruncated)     

    
    @staticmethod
    def parse_versions(xml):
        if xml is None:
            return None
        root = ET.fromstring(xml)
        versions = root.findall('./{0}Version'.format(ParseXml.NS))
        version_list = []
        for version in versions:
            Key = version.find("./{0}Key".format(ParseXml.NS))
            Key =  Key.text if Key is not None else None    
            VersionId = version.find("./{0}VersionId".format(ParseXml.NS))
            VersionId =  VersionId.text if VersionId is not None else None    
            IsLatest = version.find("./{0}IsLatest".format(ParseXml.NS))
            IsLatest =  IsLatest.text if IsLatest is not None else None    
            LastModified = version.find("./{0}LastModified".format(ParseXml.NS))
            LastModified =  LastModified.text if LastModified is not None else None    
            ETag = version.find("./{0}ETag".format(ParseXml.NS))
            ETag =  ETag.text if ETag is not None else None    
            Size = version.find("./{0}Size".format(ParseXml.NS))
            Size =  Size.text if Size is not None else None    
            owner = version.find("./{0}Owner".format(ParseXml.NS))
            Owners = None
            if owner is not None:  
                ID = version.find(".//{0}ID".format(ParseXml.NS))
                ID =  ID.text if ID is not None else None    
                DisplayName = version.find(".//{0}DisplayName".format(ParseXml.NS))
                DisplayName =  DisplayName.text if DisplayName is not None else None 
                Owners = Owner(ID,DisplayName)
                  
            StorageClass = version.find("./{0}StorageClass".format(ParseXml.NS))
            StorageClass =  StorageClass.text if StorageClass is not None else None 
            
            Version = ObjectVersion(Key,VersionId,IsLatest,LastModified,ETag,Size,Owners,StorageClass)
            version_list.append(Version) 
        return version_list             
    
    @staticmethod
    def parse_markers(xml):
        if xml is None:
            return None
        root = ET.fromstring(xml)
        markers = root.findall('./{0}DeleteMarker'.format(ParseXml.NS))
        marker_list = []
        for marker in markers:
            Key = marker.find("./{0}Key".format(ParseXml.NS))
            Key =  Key.text if Key is not None else None    
            VersionId = marker.find("./{0}VersionId".format(ParseXml.NS))
            VersionId =  VersionId.text if VersionId is not None else None    
            IsLatest = marker.find("./{0}IsLatest".format(ParseXml.NS))
            IsLatest =  IsLatest.text if IsLatest is not None else None    
            LastModified = marker.find("./{0}LastModified".format(ParseXml.NS))
            LastModified =  LastModified.text if LastModified is not None else None       
            owner = marker.find("./{0}Owner".format(ParseXml.NS))
            Owners = None
            if owner is not None:  
                ID = marker.find(".//{0}ID".format(ParseXml.NS))
                ID =  ID.text if ID is not None else None    
                DisplayName = marker.find(".//{0}DisplayName".format(ParseXml.NS))
                DisplayName =  DisplayName.text if  DisplayName is not None  else None 
                Owners = Owner(ID,DisplayName)
         
            Marker= ObjectDeleteMarker(Key,VersionId,IsLatest,LastModified,Owners)
            marker_list.append(Marker) 
        return marker_list  
    
    @staticmethod
    def parse_commonPrefixs(xml):
        if xml is None:
            return None
        root = ET.fromstring(xml)
        prefixs = root.findall('./{0}CommonPrefixes'.format(ParseXml.NS))
        prefix_list = []
        for prefix in prefixs:
            Prefix =  prefix.find("./{0}Prefix".format(ParseXml.NS))
            Prefix =  Prefix.text if Prefix is not None else None 
            Pre = CommonPrefix(Prefix)  
            prefix_list.append(Pre)
        return  prefix_list
    
    
    
    
    
    
    
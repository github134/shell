#coding=utf-8

import xml.etree.ElementTree as ET
from com.obs.response.nameSpace import NameSpace

class GetBucketStoragePolicyResponse(object):
    #===========================================================================
    # 获取桶的复制策略返回信息
    #===========================================================================
    def __init__(self, policyName):
        
        self.policyName = policyName
    
    #===========================================================================
    # 定义静态方法，用来解析xml，最后返回GetBucketStoragePolicyResponse对象
    #===========================================================================
    @staticmethod    
    def parse_xml(xml):
        if xml is not None:
            return GetBucketStoragePolicy().parse_result(xml)
        
class GetBucketStoragePolicy:
    
    def __init__(self):
        self.policyName = ""  # Name对象
    
    #===========================================================================
    # 获取Result相关信息
    #===========================================================================
    @staticmethod
    def parse_result(xml):  
        NS = NameSpace.getNameSpace()     
        root = ET.fromstring(xml)
        policyName = root.find('.//{0}Name'.format(NS)).text      
        return GetBucketStoragePolicyResponse(policyName)  # 返回GetBucketStoragePolicyResponse的对象   

#coding=utf-8

class OptionsResp(object):
    '''
    classdocs
    '''


    def __init__(self,accessContorlAllowOrigin = None,
                accessContorlAllowHeaders = None,
                accessContorlAllowMethods = None,
                accessContorlExposeHeaders = None,
                accessContorlMaxAge = None):
        '''
        Constructor
        '''
        self.accessContorlAllowOrigin = accessContorlAllowOrigin
        self.accessContorlAllowHeaders = accessContorlAllowHeaders
        self.accessContorlAllowMethods = accessContorlAllowMethods
        self.accessContorlExposeHeaders = accessContorlExposeHeaders
        self.accessContorlMaxAge = accessContorlMaxAge
    
    @staticmethod
    def parse_header(headers):
        option = OptionsResp()
        i = 0
        for v in headers:
            if len(v) <= 1:
                pass
            if 'access-control-allow-origin' == v[0]:
                i = 1
                option.accessContorlAllowOrigin = v[1]
            elif 'access-control-allow-headers' == v[0]:
                i = 1
                option.accessContorlAllowHeaders = v[1]
            elif 'access-control-allow-methods' == v[0]:
                i = 1
                option.accessContorlAllowMethods = v[1]
            elif 'access-control-expose-headers' == v[0]:
                i = 1
                option.accessContorlExposeHeaders = v[1]
            elif 'access-control-max-age' == v[0]:
                i = 1
                option.accessContorlMaxAge = v[1]
        if i == 1:    
            return option
        return None

#coding=utf-8

import sys
import xml.etree.ElementTree as ET

from com.obs.response.complete_multipart_upload_response import CompleteMultipartUploadResponse
from com.obs.response.copy_object_response import CopyObjectResponse
from com.obs.response.copy_part_response import CopyPartResponse
from com.obs.response.delete_objects_response import DeleteObjectsResponse
from com.obs.response.get_bucket_quota_response import GetBucketQuotaResponse
from com.obs.response.get_bucket_storage_info_response import GetBucketStorageInfoResponse
from com.obs.response.get_bucket_storage_policy_response import GetBucketStoragePolicyResponse
from com.obs.response.initiate_multipart_upload_response import InitiateMultipartUploadResponse
from com.obs.response.list_parts_response import ListPartsResponse
from com.obs.response.list_buckets_response import ListBucketsResponse
from com.obs.response.list_objects_response import ListObjectsResponse
from com.obs.response.lifecycle_response import LifecycleResponse
from com.obs.response.location_responce import LocationResponce
from com.obs.models.logging import Logging
from com.obs.response.bucket_vesion_response import BucketVesion
from com.obs.response.bucket_website_response import BucketWebsite
from com.obs.response.list_multipart_uploads_response import ListMultipartUploadsResponse
from com.obs.response.object_version_response import ObjectVersions
from com.obs.models.policy import Policy
from com.obs.models.acl import ACL
from com.obs.models.cors_rule import CorsRule
from com.obs.response.options_response import OptionsResp
from com.obs.log.Log import LOG, DEBUG, INFO
from com.obs.response.nameSpace import NameSpace, NS

class GetResult(object):
    #===========================================================================
    # 接口响应信息。
    #===========================================================================
    def __init__(self, code, message, status, reason, body, requestId, hostId, resource, headers=None):
        #===========================================================================
        # 初始化响应参数。
        # @param status 状态码，用于描述响应类型。
        # @param reason 原因短语，给出了关于状态码的简单的文本描述。
        # @param errorCode 错误响应消息体，错误响应对应的HTTP消息返回码。
        # @param errorMessage 错误响应消息体，具体错误更全面、详细的英文解释。
        # @param body 响应消息元素。
        # @param requestId 本次错误请求的请求ID，用于内部错误定位。。
        # @param hostId 返回该消息的服务端ID。
        # @param resource 该错误相关的桶或对象资源。
        # @param header 响应消息头，当错误发生时，消息头中都会包含： Content-Type: application/xml。
        #===========================================================================
        self.status = status
        self.reason = reason
        self.errorCode = code
        self.errorMessage = message
        self.body = body
        self.requestId = requestId
        self.hostId = hostId
        self.resource = resource
        self.header = headers
    
    #===========================================================================
    # 定义静态方法，用来解析xml，最后返回GetResult对象
    #===========================================================================
    @staticmethod    
    def parse_xml(result, headerToBodyList=None):
        if result is not None:
            return Result.parse_result(result, headerToBodyList)

class ResultBody(dict):
    def __init__(self, **kwargs):
        super(ResultBody, self).__init__(**kwargs)

    def __getattr__(self, item):
        return self.get(item)

    def __setattr__(self, key, value):
        self[key] = value

    def __delattr__(self, item):
        del self[item]


class Result:
    NS_SPACE = ""
    method_list = {"getObjectAcl":ACL,
				   "deleteObjects":DeleteObjectsResponse,
				   "copyObject":CopyObjectResponse,
                   "initiateMultipartUpload":InitiateMultipartUploadResponse,
				   "copyPart":CopyPartResponse,
                   "completeMultipartUpload":CompleteMultipartUploadResponse,
				   "listParts":ListPartsResponse,
                   "getBucketStorageInfo":GetBucketStorageInfoResponse,
				   "getBucketQuota":GetBucketQuotaResponse,
                   "getBucketStoragePolicy":GetBucketStoragePolicyResponse,
                   "getBucketLifecycleConfiguration":LifecycleResponse,
                   "getBucketPolicy":Policy,
                   "getBucketLocation":LocationResponce,
                   "getBucketLoggingConfiguration":Logging,
                   "getBucketVersioningConfiguration":BucketVesion,
                   "listVersions":ObjectVersions,
                   "getBucketWebsiteConfiguration":BucketWebsite,
                   "listBuckets":ListBucketsResponse,
                   "listObjects":ListObjectsResponse,
                   "listMultipartUploads":ListMultipartUploadsResponse,
                   "getBucketAcl":ACL,
                   "getBucketCors":CorsRule,
				   "parse_xml":GetResult					
                   }

    def __init__(self):
        pass
    #===========================================================================
    # 获取Result相关信息
    #===========================================================================
    @staticmethod
    def parse_result(result, headerToBodyList=None):
        xml = result.read()
        
        status = int(result.status)
        reason = result.reason
        code = None
        message = None
        body = None
        requestId = None
        hostId = None
        resource = None
        methodName = sys._getframe().f_back.f_back.f_code.co_name
        headers = result.getheaders()

        if isinstance(headerToBodyList, list):
            if status < 300:
                headerToBody = (header for header in headers if len(header) == 2 and header[0] in headerToBodyList)
                body = ResultBody()
                for k,v in headerToBody:
                    key = ''.join([x.capitalize() for x in k.split('-')])
                    key = key[0].lower() + key[1:]
                    body[key] = v

        if methodName == 'optionBucket' or methodName == 'optionObject':
            if status < 300:
                body = OptionsResp.parse_header(headers)

        if xml:
            LOG(DEBUG, "recv Msg:%s", xml)
            if status < 300:
                for i in range(len(NS)):
                    try:
                        NameSpace.setNameSpace(NS[i])
                        body = Result.method_list[methodName].parse_xml(xml)
                    except AttributeError:
                        # 处理200 返回错误的问题
                        if (xml is not None):
                            root = ET.fromstring(xml)
                            code = root.find('./{0}Code'.format(Result.NS_SPACE))     
                            code = code.text if code is not None else None
                            message = root.find('./{0}Message'.format(Result.NS_SPACE))
                            message = message.text if message is not None else None
                            requestId = root.find('./{0}RequestId'.format(Result.NS_SPACE))
                            requestId = requestId.text if requestId is not None else None
                            hostId = root.find('./{0}HostId'.format(Result.NS_SPACE))
                            hostId = hostId.text if hostId is not None else None
                            key = root.find('./{0}Key'.format(Result.NS_SPACE))
                            bucket = root.find('./{0}BucketName'.format(Result.NS_SPACE))
                            resource = bucket if bucket is not None else key
                            resource = resource.text if resource is not None else None
                        else:
                            raise AttributeError
                        continue
                    if(body is None and i < len(NS)-1):
                        continue
                    break
            else:      
                root = ET.fromstring(xml)
                code = root.find('./{0}Code'.format(Result.NS_SPACE))     
                code = code.text if code is not None else None
                message = root.find('./{0}Message'.format(Result.NS_SPACE))
                message = message.text if message is not None else None
                requestId = root.find('./{0}RequestId'.format(Result.NS_SPACE))
                requestId = requestId.text if requestId is not None else None
                hostId = root.find('./{0}HostId'.format(Result.NS_SPACE))
                hostId = hostId.text if hostId is not None else None
                key = root.find('./{0}Key'.format(Result.NS_SPACE))
                bucket = root.find('./{0}BucketName'.format(Result.NS_SPACE))
                resource = bucket if bucket is not None else key
                resource = resource.text if resource is not None else None
                
        LOG(INFO, 'http response result:status:%d,reason:%s,code:%s,message:%s,headers:%s', status, reason, code, message, headers)                
        
        return GetResult(code, message, status, reason, body, requestId, hostId, resource, headers)


#coding=utf-8

import xml.etree.ElementTree as ET
from com.obs.response.nameSpace import NameSpace

class InitiateMultipartUploadResponse(object):
    #===========================================================================
    # 初始化上传段任务响应
    #===========================================================================
    def __init__(self, bucket_name, object_key, upload_id):
        self.bucketName = bucket_name
        self.objectKey = object_key
        self.uploadId = upload_id
        
    #===========================================================================
    # 定义静态方法，用来解析xml，最后返回InitiateMultipartUploadResponse对象
    #===========================================================================
    @staticmethod    
    def parse_xml(xml):
        if xml is not None:
            return CreateMultipartUpload().parse_result(xml)

class CreateMultipartUpload(object):
    
    NS = NameSpace.getNameSpace()
    
    def __init__(self):
        pass
    
    #===========================================================================
    # 获取Result相关信息
    #===========================================================================
    @staticmethod
    def parse_result(xml):
        CreateMultipartUpload.NS = NameSpace.getNameSpace()       
        root = ET.fromstring(xml)
        bucket_name = root.find('.//{0}Bucket'.format(CreateMultipartUpload.NS)).text      
        object_key = root.find('.//{0}Key'.format(CreateMultipartUpload.NS)).text      
        upload_id = root.find('.//{0}UploadId'.format(CreateMultipartUpload.NS)).text      
        return InitiateMultipartUploadResponse(bucket_name, object_key, upload_id)  # 返回InitiateMultipartUploadResponse对象   
        

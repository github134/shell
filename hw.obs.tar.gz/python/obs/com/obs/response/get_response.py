#coding=utf-8

import os, sys

from com.obs.response.get_result import GetResult
from com.obs.utils.utils import Utils
from com.obs.log.Log import LOG, DEBUG

reload(sys)
sys.setdefaultencoding("utf-8")

class GetResponse(object):
    #===========================================================================
    # 获取对象返回信息
    #===========================================================================
    
    def __init__(self, code, message, status, reason, obj, requestId, hostId, resource, header):
        self.status = status
        self.reason = reason
        self.errorCode = code
        self.errorMessage = message
        self.body = obj
        self.requestId = requestId
        self.hostId = hostId
        self.resource = resource
        self.header = header
    
    #===========================================================================
    # 静态方法，返回s3的对象
    #===========================================================================
    @staticmethod
    def parse_xml(response, path=None, key=None):
        temp = ""
        if not response.status < 400:
            result = GetResult.parse_xml(response)
        if response.status < 400:
            temp = GetResponse.get_data(response, path, key)
            result = GetResult.parse_xml(response)
        if not path:      
            path = os.path.abspath(os.path.dirname(sys.argv[0]))
            temp = os.path.join(path, key[key.rfind("/") + 1:])
        body = "DownloadPath : %s" % str(temp)
        status = result.status      
        reason = result.reason     
        code = result.errorCode      
        message = result.errorMessage  
        requestId = result.requestId
        hostId = result.hostId
        resource = result.resource    
        header = result.header
        return GetResponse(code, message, status, reason, body, requestId, hostId, resource, header)
        
    #===========================================================================
    # 静态方法，获取s3对象的元数据
    #===========================================================================
    @staticmethod
    def parse_metadata(response):
        
        metamap = {}
        for item in response.getheaders():
            if item[0].startswith(Utils.METADATA_PREFIX):
                key = item[0][len(Utils.METADATA_PREFIX):]
                metamap[key] = item[1]
        return metamap
    
    #===========================================================================
    # 静态方法，获取s3对象的数据
    #===========================================================================
    @staticmethod
    def get_data(response, path=None, key=None):
        data = []
        CHUNKSIZE = 65563
        if not path:
            path = os.path.abspath(os.path.dirname(sys.argv[0]))
        else:
            if not os.path.exists(unicode(path, "UTF-8")):
                os.makedirs(unicode(path, "UTF-8"), 0755)
        file_path = os.path.join(path, unicode(key[key.rfind("/") + 1:], "UTF-8"))
        LOG(DEBUG, "DownloadPath : %s", file_path)
        with open(file_path, 'wb') as f:
            while True:
                chunk = response.read(CHUNKSIZE)
                if not chunk:
                    break
                f.write(chunk)
        return file_path



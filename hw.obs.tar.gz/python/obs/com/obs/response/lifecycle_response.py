#coding=utf-8

import xml.etree.ElementTree as ET

from com.obs.models.expiration import Expiration
from com.obs.models.rule import Rule
from com.obs.models.date_time import DateTime
from com.obs.response.nameSpace import NameSpace

class LifecycleResponse(object):
    '''
    classdocs
    '''

    def __init__(self, lifecycleConfig=None):
        '''
        Constructor
        '''
        self.lifecycleConfig = lifecycleConfig
    
    @staticmethod
    def parse_xml(xml):
        lifecycle = LifecycleConfig.parse_Lifecycle(xml)
        if (len(lifecycle) == 0):
            return None
        return LifecycleResponse(lifecycle)


        
class LifecycleConfig:
    
    NS = NameSpace.getNameSpace()
    @staticmethod 
    def parse_Lifecycle(xml):
        LifecycleConfig.NS = NameSpace.getNameSpace()
        if not xml:
            return None
        root = ET.fromstring(xml)
        rules = root.findall('./{0}Rule'.format(LifecycleConfig.NS))   
        entries = []
        for rule in rules:
            id = rule.find("./{0}ID".format(LifecycleConfig.NS)).text  # 获取bucket的名称
            prefix = rule.find("./{0}Prefix".format(LifecycleConfig.NS)).text  # 获取bucket的创建日期
            status = rule.find("./{0}Status".format(LifecycleConfig.NS)).text  
            
            d = rule.find("./{0}Expiration/{0}Date".format(LifecycleConfig.NS))
            d = d.text if d is not None else None
            date = DateTime.UTCToLocal(d)  # UTC时间转当地时间
            
            day = rule.find("./{0}Expiration/{0}Days".format(LifecycleConfig.NS))
            day = day.text if day is not None else None
            days = intern(str(day))
            expira = Expiration(date, days)
            
            Rules = Rule(id, prefix, status, expira)           
            entries.append(Rules)  # 向entries列表中添加bucket对象   
        return entries

     
         

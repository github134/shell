#coding=utf-8

import xml.etree.ElementTree as ET
from com.obs.response.nameSpace import NameSpace

class BucketVesion(object):
    '''
    classdocs
    '''

    def __init__(self):
        '''
        Constructor
        '''
        pass
    
    @staticmethod
    def parse_xml(xml):
        NS = NameSpace.getNameSpace()
        root = ET.fromstring(xml)
        status = root.find("./{0}Status".format(NS)) 
        if status is not None:
            return status.text
        return None

    
    
    
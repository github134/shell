#coding=utf-8

import platform
import os
import sys
import logging.handlers
from com.obs.log.ReadConfig import LogConf

CRITICAL = logging.CRITICAL
ERROR = logging.ERROR
WARNING = logging.WARNING
INFO = logging.INFO
DEBUG = logging.DEBUG
NOTSET = logging.NOTSET

LOGMODE = 'MYLOGGER'

def LogInit(logConfig=LogConf()): 
    logCog = logConfig
    if not logCog:
        raise Exception('log config is None')
    
    # 创建一个logger
    logger = logging.getLogger(LOGMODE)
    logger.setLevel(logging.DEBUG)
  
    # 创建日志路劲
    if not os.path.exists(logCog.LogFileDir):
        os.makedirs(logCog.LogFileDir, 0755)
    
    if platform.system() == 'Windows':
        logfilepath = logCog.LogFileDir + '\\' + logCog.LogFileName
    else:
        logfilepath = logCog.LogFileDir + '/' + logCog.LogFileName
        
    # 创建一个handler，用于写入日志文件
    formatter_handle = logging.handlers.RotatingFileHandler(logfilepath, maxBytes=1024 * 1024 * logCog.LogFileSize, backupCount=logCog.LogFileNumber)
    formatter_handle.setLevel(logCog.LogFileLevel)
    
    formatter = logging.Formatter('%(asctime)s|%(levelname)-5s|Storage|1|HTTP+XML|%(message)s|')
    formatter_handle.setFormatter(formatter)
    
    # 给logger添加handler
    logger.addHandler(formatter_handle)
    if logCog.PrintLogToConsole == 1: 
        # 再创建一个handler，用于输出到控制台
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logCog.PrintLogLevel)
    
        # 定义handler的输出格式
        console_handler.setFormatter(formatter)
       
        # 给logger添加handler
        logger.addHandler(console_handler)
       
def LOG(level, msg, *args, **kwargs):
    
    logger = logging.getLogger(LOGMODE)
    funcname = sys._getframe().f_back.f_code.co_name
    line = sys._getframe().f_back.f_lineno 
    Msg = '%(name)s,%(lineno)d|' % {'name':funcname, 'lineno':int(line)} 
    Msg += msg
    msg = Msg
    
    if(level == CRITICAL):
        logger.critical(msg, *args, **kwargs)
    if(level == ERROR):
        logger.error(msg, *args, **kwargs)
    if(level == WARNING):   
        logger.warning(msg, *args, **kwargs)
    if(level == INFO):
        logger.info(msg, *args, **kwargs)
    if(level == DEBUG):
        logger.debug(msg, *args, **kwargs)
    if(level == NOTSET):
        logger.notset(msg, *args, **kwargs)
            

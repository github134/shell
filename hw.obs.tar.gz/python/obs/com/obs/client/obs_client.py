#coding=utf-8

import datetime
import httplib
import os, sys
import socket
import types
import urllib

from com.obs.log.Log import LOG, INFO, ERROR, DEBUG
from com.obs.models.acl import ACL
from com.obs.models.complete_multipart_upload_request import CompleteMultipartUploadRequest
from com.obs.models.copy_object_header import CopyObjectHeader
from com.obs.models.cors_rule import CorsRule
from com.obs.models.create_bucket_header import CreateBucketHeader
from com.obs.models.delete_objects_request import DeleteObjectsRequset
from com.obs.models.get_object_header import GetObjectHeader
from com.obs.models.get_object_request import GetObjectRequest
from com.obs.models.lifecycle import Lifecycle
from com.obs.models.list_multipart_uploads_request import ListMultipartUploadsRequest
from com.obs.models.logging import Logging
from com.obs.models.options import Options
from com.obs.models.policy import Policy
from com.obs.models.put_object_header import PutObjectHeader
from com.obs.models.s3object import S3Object
from com.obs.models.version_set import Version
from com.obs.models.versions import Versions
from com.obs.models.restore import Restore
from com.obs.models.website_configuration import WebsiteConfiguration
from com.obs.response.error_response import ErrorMsg
from com.obs.response.get_response import GetResponse
from com.obs.response.get_result import GetResult
from com.obs.utils.request_format import PathFormat
from com.obs.utils.request_format import RequestFormat
from com.obs.utils.utils import Utils
from com.obs.utils.v4_authentication import V4Authentication
from com.obs.utils.encryptor import encrypt_password
from com.obs.utils.cryptor  import AESCryptor

reload(sys)
sys.setdefaultencoding("utf-8")

class ObsClient(object):
    
               
    def __init__(self, access_key_id, secret_access_key, is_secure=True, server=Utils.DEFAULT_HOST,
            signature="s3", region=None, path_style=True, ssl_verify=True):  
        #===========================================================================
        # __init__ 初始化
        # @param access_key_id     连接华为S3的AK
        # @param secret_access_key 鉴权使用的SK，可用于字符串的签名
        # @param is_secure         连接是否使用SSL
        # @param server            连接的服务器
        # @param signature         鉴权方式 取值为 s3或v4
        # @param region            服务器所在区域，当鉴权方式为v4时，必选
        # @param path_style        连接请求的格式是否是路径方式，True 是，False 不是
        # @param ssl_verify        是否验证服务器CA证书，True 是，False 不是
        #===========================================================================        
        self.access_key_id = encrypt_password(access_key_id,"A")
        self.secret_access_key = encrypt_password(secret_access_key,"S")
        self.is_secure = is_secure
        self.server = server
        self.signature = signature
        self.region = region
        self.port = Utils.SECURE_PORT if is_secure else Utils.INSECURE_PORT
        self.path_style = path_style
        if path_style == True:
            self.calling_format = RequestFormat.get_pathformat()
        else:
            self.calling_format = RequestFormat.get_subdomainformat()
        self.cryptor = AESCryptor()
        self.pw_keyA, self.pw_ivA, self.key_ivA = self.cryptor.decrypt_dependency("A")
        self.pw_keyS, self.pw_ivS, self.key_ivS = self.cryptor.decrypt_dependency("S")
        self.ssl_verify = ssl_verify


    def headBucket(self, bucketName):
        #===========================================================================
        # 检查存储空间是否存在
        # @param bucketName  待检查的存储空间名
        # @return GetResult
        #===========================================================================   
        LOG(INFO, 'enter headBucket ...')
        conn = self.make_request("HEAD", bucketName, "", None, None, None)
        response = conn.getresponse()
        
        return GetResult.parse_xml(response)

    def getBucketMetadata(self, bucketName, origin=None, requestHeaders=None):
        #===========================================================================
        # 获取桶元数据信息
        # @param bucketName           桶名称
        # @param origin               预请求指定的跨域请求
        # @param requestHeaders       实际请求可以带的HTTP头域
        # @return GetResult           获取对象元数据响应
        #===========================================================================
        LOG(INFO, 'enter getBucketMetadata ...')
        headers = {}
        if origin and isinstance(origin, basestring):
            headers['Origin'] = origin
        result = None
        if len(headers) == 1 and isinstance(requestHeaders,list) and len(requestHeaders) > 1:
            for requestHeader in requestHeaders:
                headers['Access-Control-Request-Headers'] = requestHeader
                conn = self.make_request('HEAD', bucketName, '', None, headers, None)
                temp = GetResult.parse_xml(conn.getresponse())
                if temp.status < 300:
                    if result:
                        temp_allow_headers = []
                        findItem = None
                        if result.header:
                            for item in result.header:
                                if item[0] == 'access-control-allow-headers':
                                    temp_allow_headers.append(item[1])
                                    findItem = item
                                    break
                        if temp and temp.header:
                            for k, v in temp.header:
                                if k == 'access-control-allow-headers':
                                    temp_allow_headers.append(v)
                                    break
                        if findItem:
                            result.header.remove(findItem)
                        if len(temp_allow_headers) > 1:
                            result.header.append(('access-control-allow-headers',', '.join(temp_allow_headers)))
                        elif len(temp_allow_headers) == 1:
                            result.header.append(('access-control-allow-headers',temp_allow_headers[0]))
                    else:
                        result = temp
                else:
                    return temp
        else:
            _requestHeaders = requestHeaders[0] if isinstance(requestHeaders,list) and len(requestHeaders) == 1 else requestHeaders
            if _requestHeaders:
                headers['Access-Control-Request-Headers'] = _requestHeaders
            conn = self.make_request('HEAD', bucketName, '', None, headers, None)
            result = GetResult.parse_xml(conn.getresponse())

        if result.status < 300 and not result.errorCode and result.header:
            flag = False
            for k, v in result.header:
                if k == 'x-default-storage-class':
                    flag = True
                    break
            if not flag:
                result.header.append(('x-default-storage-class', 'STANDARD'))
        return result

    def createBucket(self, bucketName, header=CreateBucketHeader(), location=None):
        #===========================================================================
        # 创建存储空间
        # @param bucketName     存储空间名.一个用户可以拥有的存储空间的数量不能超过100个。
        # @param header         HTTP头
        # @param location       存储空间所在区域
        # @return GetResult  
        #=========================================================================== 
        LOG(INFO, 'enter createBucket ...')
        bucketPath = CreateBucketHeader.to_xml(location)
        try:
            obj = S3Object(bucketPath, None)
            
            headers = header.assembleHeader() if header is not None else None
            
            conn = self.make_request("PUT", bucketName, "", None, headers, obj)
            if bucketPath:
                self.send_message(conn, bucketPath)    
            response = conn.getresponse()
            return GetResult.parse_xml(response)
        finally:
            if bucketPath:
                os.remove(bucketPath) 
          
    def setBucketLifecycleConfiguration(self, bucketName, lifecycle=Lifecycle()):
        #==========================================================================
        # 获取桶的生命周期配置
        # @param bucketName             存储空间名
        # @param lifecycle =Lifecycle() 生命周期配置
        # @return  GetResult
        #==========================================================================
        LOG(INFO, 'enter setBucketLifecycleConfiguration ...')
        obj = S3Object(None, None)
        lifecycle_path = None
        if lifecycle is not None:
            lifecycle_path = lifecycle.to_xml()
            obj = S3Object(lifecycle_path, None) 
        try:
            path_args = {}
            path_args["lifecycle"] = None
            
            headers = None
            md5_value = ''      
            CHUNKSIZE = 65563
            if lifecycle is not None and lifecycle_path is not None:
                with open(lifecycle_path, 'rb') as f:
                    while True:
                        chunk = f.read(CHUNKSIZE)
                        if not chunk:
                            break               
                        md5_value += chunk
     
                md5Code = Utils.md5_encode(md5_value)
                base64_md5 = Utils.base64_encode(md5Code) 
                                   
                headers = {}
                headers["Content-MD5"] = base64_md5
                    
            conn = self.make_request("PUT", bucketName, None, path_args, headers, obj) 
            if lifecycle is not None and lifecycle_path is not None:
                self.send_message(conn, lifecycle_path)
            result = conn.getresponse()
            return GetResult.parse_xml(result)
        finally:
            if lifecycle_path:
                os.remove(lifecycle_path) 
    
          
    def getBucketLifecycleConfiguration(self, bucketName):
        #==========================================================================
        # 获取桶的生命周期配置
        # @param bucketName       存储空间名
        # @return  GetResult,GetResult.body：LifecycleResponse
        #==========================================================================
        LOG(INFO, 'enter getBucketLifecycleConfiguration ...')
        if ErrorMsg.is_obj_none(bucketName):
            return ErrorMsg.GetError()
        path_args = {}
        path_args["lifecycle"] = None
        
        conn = self.make_request("GET", bucketName, None, path_args, None, None)        
        result = conn.getresponse()
    
        return GetResult.parse_xml(result)
        

    def deleteBucketLifecycleConfiguration(self, bucketName):
        #==========================================================================
        # 删除桶的生命周期配置
        # @param bucketName     存储空间名
        # @return  GetResult
        #==========================================================================
        
        LOG(INFO, 'enter deleteBucketLifecycleConfiguration ...')
        
        path_args = {}
        path_args["lifecycle"] = None
        
        conn = self.make_request("DELETE", bucketName, None, path_args, None, None)        
        result = conn.getresponse()
        
        return GetResult.parse_xml(result)
    
          
    def setBucketPolicy(self, bucketName, policyJSON):
        #==========================================================================
        # 获取桶的策略
        # @param bucketName 存储空间名
        # @policyJSON       策略信息，JSON格式的字符串
        # @retrun  GetResult
        #========================================================================== 
        LOG(INFO, 'enter setBucketPolicy ...')
         
        path_args = {}
        path_args["policy"] = None
        obj = S3Object(None, None)
        path = None
        if policyJSON is not None:
            path = Policy(str(policyJSON)).to_json()
            obj = S3Object(path, None)
        try:
            conn = self.make_request("PUT", bucketName, None, path_args, None, obj)
            if  path:
                self.send_message(conn, path)    
            result = conn.getresponse()
            return GetResult.parse_xml(result)
        finally:
            if path:
                os.remove(path) 


    def getBucketPolicy(self, bucketName):
        #==========================================================================
        # 获取桶的策略
        # @param bucketName          存储空间名
        # @return GetResult          GetResult.body:Policy
        #========================================================================== 
        LOG(INFO, 'enter getBucketPolicy ...')
        if ErrorMsg.is_obj_none(bucketName):
            return ErrorMsg.GetError()
        path_args = {}
        path_args["policy"] = None
        
        conn = self.make_request("GET", bucketName, None, path_args, None, None)        
        result = conn.getresponse() 
        return GetResult.parse_xml(result) 


    
    def deleteBucketPolicy(self, bucketName):
        #==========================================================================
        # 删除桶的策略
        # @param bucketName         存储空间名
        # @return  GetResult
        #========================================================================== 
        LOG(INFO, 'enter deleteBucketPolicy ...')
          
        path_args = {}
        path_args["policy"] = None
        
        conn = self.make_request("DELETE", bucketName, None, path_args, None, None)        
        result = conn.getresponse()    
        return GetResult.parse_xml(result)
                   
     
    def  getBucketLocation(self, bucketName):
        #==========================================================================
        # 获取桶的区域位置
        # @param bucketName         存储空间名
        # @return GetResult         GetResult.body：LocationResponce
        #========================================================================== 
        LOG(INFO, 'enter getBucketLocation ...')
        if ErrorMsg.is_obj_none(bucketName):
            return ErrorMsg.GetError()       
        path_args = {}
        path_args["location"] = None
        
        conn = self.make_request("GET", bucketName, None, path_args, None, None)        
        result = conn.getresponse()
        return GetResult.parse_xml(result)
         
     
     
    def setBucketLoggingConfiguration(self, bucketName, logstatus=Logging()):
        #==========================================================================
        # 设置桶的日志管理配置
        # @param bucketName           存储空间名
        # @param logstatus=Logging()  日志状态信息
        # @return GetResult
        #==========================================================================
        LOG(INFO, 'enter setBucketLoggingConfiguration...')
        acl_path = None
        obj = S3Object(None, None)
        if logstatus is not None:
            acl_path = logstatus.to_xml()     
            obj = S3Object(acl_path, None)
        try:      
            path_args = {}       
            path_args["logging"] = None
    
            conn = self.make_request("PUT", bucketName, None, path_args, None, obj)
            
            CHUNKSIZE = 65563
            if acl_path:
                self.send_message(conn, acl_path) 
            result = conn.getresponse()
            return GetResult.parse_xml(result)   
        finally:
            if acl_path:
                os.remove(acl_path) 
        
    def getBucketLoggingConfiguration(self, bucketName):
        #==========================================================================
         # 获取桶的日志管理配置
        # @param bucketName          存储空间名
        # @retrun GetResult          GetResult.body:Logging
        #==========================================================================  
        LOG(INFO, 'enter getbucketLoggingConfiguration ...')
        if ErrorMsg.is_obj_none(bucketName):
            return ErrorMsg.GetError()   
        path_args = {}
        path_args["logging"] = None
        
        conn = self.make_request("GET", bucketName, None, path_args, None, None)        
        result = conn.getresponse()

        return GetResult.parse_xml(result)

    
    def setBucketVersioningConfiguration(self, bucketName, status=None):
        #==========================================================================
        # 设置桶的多版本信息
        # @param bucketName        存储空间名
        # @param status            版本状态Enabled Suspended
        # @retrun GetResult
        #==========================================================================
        LOG(INFO, 'enter setBucketVersioningConfiguration ...')
        path_args = {}
        path_args["versioning"] = None
        
        path = Version.to_xml(status)
        obj = S3Object(path, None)
        try:
            conn = self.make_request("PUT", bucketName, None, path_args, None, obj)
        
            if path:
                self.send_message(conn, path)
            result = conn.getresponse()
            return GetResult.parse_xml(result) 
        finally:
            if path:
                os.remove(path) 
    
    
    def getBucketVersioningConfiguration(self, bucketName):
        #==========================================================================
        # 获取桶的多版本信息
        # @param bucketName         存储空间名
        # @return GetResult         GetResult.body:BucketVesion
        #==========================================================================
        LOG(INFO, 'enter getBucketVersioningConfiguration ...')
        if ErrorMsg.is_obj_none(bucketName):
            return ErrorMsg.GetError()  
        path_args = {}
        path_args["versioning"] = None
        
        conn = self.make_request("GET", bucketName, None, path_args, None, None)        
        result = conn.getresponse()
        
        return GetResult.parse_xml(result)
     

    
    
    def listVersions(self, bucketName, version=Versions()):
        #==========================================================================
        # 获取桶内对象多版本信息
        # @param bucketName          存储空间名
        # @param version= Versions() 版本信息 
        # @return GetResult          GetResult.body:ObjectVersions
        #==========================================================================
        LOG(INFO, 'enter listVersions ...')
        if ErrorMsg.is_obj_none(bucketName):
            return ErrorMsg.GetError()
        if version:
            path_args = version.assembleToDict() 
        else:
            path_args = {}
            path_args["versions"] = None   
                
        conn = self.make_request("GET", bucketName, None, path_args, None, None)        
        result = conn.getresponse()
        
        return GetResult.parse_xml(result)

    
    def setBucketWebsiteConfiguration(self, bucketName, website=WebsiteConfiguration()):
        #==========================================================================
        # 设置桶的网站配置信息
        # @param bucketName                     桶名
        # @param website=WebsiteConfiguration() 网络配置信息
        # @return  GetResult
        #==========================================================================
        LOG(INFO, 'enter setBucketWebsiteConfiguration ...')
        obj = S3Object(None, None)
        website_path = None
        if website is not None:
            website_path = website.to_xml()
            obj = S3Object(website_path, None) 
        try:  
            path_args = {}       
            path_args["website"] = None
    
            conn = self.make_request("PUT", bucketName, None, path_args, None, obj)
            
            if website and website_path:
                self.send_message(conn, website_path)
            result = conn.getresponse()
            return GetResult.parse_xml(result)
        finally:
            if website_path:
                os.remove(website_path) 

    
    def getBucketWebsiteConfiguration(self, bucketName):
        #==========================================================================
        # 获取桶的网站配置信息
        # @param bucketName  桶名
        # @return GetResult  GetResult.body:BucketWebsite
        #==========================================================================
        LOG(INFO, 'enter getBucketWebsiteConfiguration ...')
        if ErrorMsg.is_obj_none(bucketName):
            return ErrorMsg.GetError()  
        path_args = {}
        path_args["website"] = None
        
        conn = self.make_request("GET", bucketName, None, path_args, None, None)        
        result = conn.getresponse()
        
        return GetResult.parse_xml(result)
        
      
    def deleteBucketWebsiteConfiguration(self, bucketName):
        #==========================================================================
        # 获取桶的网站配置信息
        # @param bucketName     桶名
        # @retrun  GetResult
        #==========================================================================
        LOG(INFO, 'enter deleteBucketWebsiteConfiguration ...')
          
        path_args = {}
        path_args["website"] = None
        
        conn = self.make_request("DELETE", bucketName, None, path_args, None, None)        
        result = conn.getresponse()
       
        return GetResult.parse_xml(result)
    
    def deleteBucket(self, bucketName):
        #==========================================================================
        # 删除存储空间
        # @param bucketName 存储空间名
        # @param return  GetResult
        #==========================================================================        
        LOG(INFO, 'enter deleteBucket ...')
        conn = self.make_request("DELETE", bucketName, "", None, None, None)
        response = conn.getresponse() 
      
        return GetResult.parse_xml(response)
      

    def listBuckets(self):
        #==========================================================================
        # 罗列用户所有存储空间
        # @ retrun  GetResult,GetResult.body: ListBucketsResponse
        #==========================================================================
        LOG(INFO, 'enter listBuckets ...')
        conn = self.make_request("GET", "", "", None, None, None)        
        result = conn.getresponse()
         
        return GetResult.parse_xml(result)

      

    def listObjects(self, bucketName, prefix=None, marker=None, max_keys=None, delimiter=None):
        #===========================================================================
        # 罗列对象.
        # @param bucketName 存储空间名
        # @param prefix 对象前缀，设置此字段，带该前缀的对象才会返回，可为空
        # @param marker 所有返回的对象名的字典序必须大于marker指定的字符串的字典序
        # @param max_keys 对象返回的最大个数，输入0默认处理1000个对象，输入大于1000，实际处理1000个，返回MaxKeys为实际输入的值
        # @param delimiter 分隔符，前缀（prefix）与分隔符（delimiter）第一次出现之
        # 间的字符串讲保存到CommonPrefix字段中，返回对象列表中包含CommonPrefix 中字
        # 符串的对象将不显示。常用的字段有“/”（用于分类文件和文件夹）
        # @retrun GetResult. GetResult.body:ListObjectsResponse
        #===========================================================================  
        LOG(INFO, 'enter listObjects ...') 
        if ErrorMsg.is_obj_none(bucketName):
            return ErrorMsg.GetError()
        path_args = Utils.params_for_dict_options(prefix, marker, max_keys, delimiter)        
        conn = self.make_request("GET", bucketName, "", path_args, None, None)
        result = conn.getresponse()
      
        return GetResult.parse_xml(result)



    def listMultipartUploads(self, bucketName, multipart=ListMultipartUploadsRequest()):
        #===========================================================================
        # 列出多段上传任务
        # @param multipart:ListMultipartUploadsRequest
        # @return GetResult,GetResult.body:ListMultipartUploadsResponse
        #=========================================================================== 
        LOG(INFO, 'enter listMultipartUploads ...') 
        if ErrorMsg.is_obj_none(bucketName):
            return ErrorMsg.GetError()
        path_args = {}
        if multipart is None:
            path_args['uploads'] = None
        else:          
            path_args = multipart.params_multipart_for_dict_options()
        
        conn = self.make_request("GET", bucketName, None, path_args, None, None)
        result = conn.getresponse()
      
        return GetResult.parse_xml(result)
    

    def setBucketAcl(self, bucketName, acl=ACL(), x_amz_acl=None):
        #===========================================================================
        # 指定存储空间内写入ACL    
        # @param bucketName 存储空间名
        # @param acl ACL对象
        # @param x_amz_acl 附加头部，Permission对象值
        # @return GetResult
        #===========================================================================    
        LOG(INFO, 'enter setBucketAcl...')
       
        headers = None
        if  x_amz_acl is not None:
            headers = {'x-amz-acl':x_amz_acl}
            
        obj = S3Object(None, None)
        acl_path = None
        if acl is not None:
            acl_path = acl.to_xml()
            obj = S3Object(acl_path, None)  
        try:
            path_args = {}       
            path_args["acl"] = None
    
            conn = self.make_request("PUT", bucketName, None, path_args, headers, obj)
            
            if acl is not None and acl_path:
                self.send_message(conn, acl_path)
            result = conn.getresponse()
            return GetResult.parse_xml(result)
        finally:
            if acl_path:
                os.remove(acl_path) 
    

    def getBucketAcl(self, bucketName):
        #===========================================================================
        # 获取存储空间的ACL
        # @param bucket 存储空间名
        # @return GetResult.body:ACL
        #===========================================================================
        LOG(INFO, 'enter getBucketAcl...')
        if ErrorMsg.is_obj_none(bucketName):
            return ErrorMsg.GetError()
        key = ''   
        path_args = {}
        path_args["acl"] = None
        
        conn = self.make_request("GET", bucketName, Utils.urlencode(key), path_args, None, None)        
        result = conn.getresponse()
     
        return GetResult.parse_xml(result)
     
    def setBucketCors(self, bucketName, corsRule=None):
        #===========================================================================
        # 设置桶的CORS    
        # @param bucketName 存储空间名
        # @param corsRule CorsRule对象
        # @return GetResult
        #===========================================================================    
        LOG(INFO, 'enter setBucketCors...')
       
        obj = S3Object(None, None)
        headers = {}
        path = None
        if corsRule is not None:
            path = CorsRule.to_xml(corsRule)
            obj = S3Object(path, None)   
            CHUNKSIZE = 65563
            if path:
                md5_value = ''      
                with open(path, 'rb') as f:
                    while True:
                        chunk = f.read(CHUNKSIZE)
                        if not chunk:
                            break               
                        md5_value += chunk
                headers["Content-MD5"] = Utils.base64_encode(Utils.md5_encode(md5_value))    
        try:   
            path_args = {}       
            path_args["cors"] = None
            
            conn = self.make_request("PUT", bucketName, None, path_args, headers, obj)
            
            if corsRule is not None and path:
                self.send_message(conn, path)
            result = conn.getresponse()
            return GetResult.parse_xml(result)
        finally:
            if path:
                os.remove(path) 
    
    def deleteBucketCors(self, bucketName):
        #===========================================================================
        # 删除桶的CORS    
        # @param bucketName 存储空间名
        # @return GetResult
        #===========================================================================    
        LOG(INFO, 'enter deleteBucketCors...')
         
        path_args = {}       
        path_args["cors"] = None
               
        conn = self.make_request("DELETE", bucketName, None, path_args, None, None)       
        result = conn.getresponse()
        return GetResult.parse_xml(result)
    
    def getBucketCors(self, bucketName):
        #===========================================================================
        # 获取桶的CORS    
        # @param bucketName 存储空间名
        # @return GetResult.body:CorsRule
        #===========================================================================    
        LOG(INFO, 'enter getBucketCors...')
         
        path_args = {}       
        path_args["cors"] = None
               
        conn = self.make_request("GET", bucketName, None, path_args, None, None)       
        result = conn.getresponse()
        return GetResult.parse_xml(result)
     
    def optionsBucket(self, bucketName, option=Options()):
        #===========================================================================
        # OPTIONS桶  
        # @param bucketName 存储空间名
        # @para option  Options对象
        # @return GetResult.body:OptionResp
        #===========================================================================    
        LOG(INFO, 'enter optionsBucket...')
         
        path_args = {}   
        headers = option.to_header()   
        conn = self.make_request("OPTIONS", bucketName, None, path_args, headers, None)       
        result = conn.getresponse()
        return GetResult.parse_xml(result)
    
    def optionsObject(self, bucketName, objectKey, option=Options()):
        #===========================================================================
        # OPTIONS桶  
        # @param bucketName 存储空间名
        # @param objectKey 对象名
        # @para option  Options对象
        # @return GetResult.body:OptionResp
        #===========================================================================    
        LOG(INFO, 'enter optionsObject...')
         
        path_args = {}   
        headers = option.to_header()
                  
        conn = self.make_request("OPTIONS", bucketName, Utils.urlencode(objectKey), path_args, headers, None)       
        result = conn.getresponse()
        return GetResult.parse_xml(result)
      
    def deleteObject(self , bucketName, objectKey, versionId=None):
        #===========================================================================
        # 删除对象。
        # @param bucketName    桶名。
        # @param objectKey     对象名。
        # @param versionId     待删除对象的版本号。
        # @return GetResult     删除对象响应。
        #===========================================================================
        LOG(INFO, 'enter deleteObject ...')
        path_args = {}
        if versionId:
            path_args["versionId"] = versionId
        conn = self.make_request("DELETE", bucketName, Utils.urlencode(objectKey), path_args, None, None)
        result = conn.getresponse()   
        return GetResult.parse_xml(result)
    
    def deleteObjects(self , bucketName, deleteObjectsRequset=DeleteObjectsRequset()):
        #===========================================================================
        # 批量删除对象。
        # @param bucketName    桶名。
        # @param deleteObjectsRequset     批量删除对象列表请求。
        # @return GetResult GetResult.body:DeleteObjectsResponse 批量删除对象响应。
        #===========================================================================
        LOG(INFO, 'enter deleteObjects ...')
        file_path = deleteObjectsRequset.to_xml()
        obj = S3Object(file_path, None)
        path_args = {}
        path_args["delete"] = None
        headers = {}
        CHUNKSIZE = 65563
        try:
            if file_path:
                md5 = ''      
                with open(file_path, 'rb') as f:
                    while True:
                        chunk = f.read(CHUNKSIZE)
                        if not chunk:
                            break               
                        md5 += chunk
                headers["Content-MD5"] = Utils.base64_encode(Utils.md5_encode(md5)) 
                
            conn = self.make_request("POST", bucketName, None, path_args, headers, obj)
            if file_path:
                self.send_message(conn, file_path)
            result = conn.getresponse()
            return GetResult.parse_xml(result)
        finally:
            if file_path:
                os.remove(file_path) 
    
    def getObject(self , bucketName, objectKey, downloadPath=None, getObjectRequest=GetObjectRequest(), headers=GetObjectHeader()): 
        #===========================================================================
        # 下载对象。
        # @param bucketName    桶名。
        # @param objectKey     对象名。
        # @param downloadPath 文件下载路径，默认当前文件路径。
        # @param getObjectRequest 下载对象请求消息。
        # @param headers     GetObjectHeader,HTTP附加的消息头。
        # @return GetResponse 下载对象响应。
        #===========================================================================
        LOG(INFO, 'enter getObject ...')
        if ErrorMsg.is_obj_none(bucketName) or ErrorMsg.is_obj_none(objectKey):
            return ErrorMsg.GetError()
        header = {}
        if headers:
            header = headers.assemble_args()
        conn = self.make_request("GET", bucketName, Utils.urlencode(objectKey), getObjectRequest, header, None)
        result = conn.getresponse()
        return GetResponse.parse_xml(result, downloadPath, objectKey)         
        
    def getObjectAcl(self, bucketName, objectKey, versionId=None):
        #===========================================================================
        # 获取对象的ACL信息。
        # @param bucketName    桶名。
        # @param objectKey     对象名。
        # @param versionId     对象的版本号。
        # @return GetResult    GetResult.body:ACL 获取对象的ACL信息响应。
        #===========================================================================
        LOG(INFO, 'enter getObjectAcl ...')
        if ErrorMsg.is_obj_none(bucketName) or ErrorMsg.is_obj_none(objectKey):
            return ErrorMsg.GetError()
        path_args = {}
        path_args["acl"] = None
        if versionId:
            path_args["versionId"] = versionId
        
        conn = self.make_request("GET", bucketName, Utils.urlencode(objectKey), path_args, None, None)        
        result = conn.getresponse()
        return GetResult.parse_xml(result)
        
    def getObjectMetadata(self, bucketName, objectKey, versionId=None):
        #===========================================================================
        # 获取对象的元数据。
        # @param bucketName    桶名。
        # @param objectKey     对象名。
        # @param versionId     对象的版本号。
        # @return GetResult    GetResult.header 对象的元数据。
        #===========================================================================
        LOG(INFO, 'enter getObjectMetadata ...')
        if ErrorMsg.is_obj_none(bucketName) or ErrorMsg.is_obj_none(objectKey):
            return ErrorMsg.GetError()
        path_args = {}
        if versionId:
            path_args["versionId"] = versionId
        conn = self.make_request("HEAD", bucketName, Utils.urlencode(objectKey), path_args, None, None)
        result = conn.getresponse()
        return GetResult.parse_xml(result)
    
    def putObject(self, bucketName, objectKey, content, metadata=None, headers=PutObjectHeader()):
        #===========================================================================
        # 上传内容。
        # @param bucketName    桶名。
        # @param objectKey     对象名。
        # @param content       对象内容。
        # @param metadata      自定义的元数据。
        # @param headers       PutObjectHeader,HTTP附加的消息头。
        # @return GetResult    上传内容响应。
        #===========================================================================
        LOG(INFO, 'enter putObject ...')
        path = os.path.abspath(os.path.dirname(sys.argv[0]))
        file_path = os.path.join(path, "content.txt")
        try:
            with open(file_path, 'wb') as f:
                f.write(content)
            result = self.postObject(bucketName, Utils.urlencode(objectKey), file_path, metadata, headers)
            return result
        finally:
            if file_path:
                os.remove(file_path) 
    
    def postObject(self, bucketName, objectKey, file_path, metadata=None, headers=PutObjectHeader()):
        #===========================================================================
        # 上传对象。
        # @param bucketName    桶名。
        # @param objectKey     对象名。
        # @param file_path     对象路径。
        # @param metadata      自定义的元数据。
        # @param headers       PutObjectHeader,HTTP附加的消息头。
        # @return GetResult    上传对象响应。
        #===========================================================================
        fun_name = sys._getframe().f_back.f_code.co_name
        if not fun_name == "putObject" and not fun_name == "postObject":
            LOG(INFO, 'enter postObject ...')
            if ErrorMsg.is_file_not_exist(file_path):
                return ErrorMsg.GetError()
        try:
            _flag = os.path.isdir(unicode(file_path, "UTF-8"))
        except (UnicodeDecodeError,TypeError):
            _flag = os.path.isdir(file_path)
        if _flag:
            if not objectKey:
                objectKey = os.path.split(file_path)[1] + "/"
            else:
                objectKey += "/"
            for file in os.listdir(unicode(file_path, "UTF-8")):  # windows中文文件路径
                file = file.encode("UTF-8") 
                key = objectKey + file
                __file_path = os.path.join(file_path, file) 
                self.postObject(bucketName, key, __file_path, metadata, headers)
        else :
            if not objectKey:
                objectKey = os.path.split(file_path)[1]
        header = {}
        if headers:
            header = headers.assemble_args()
        object = S3Object(file_path, metadata) 
        conn = self.make_request("PUT", bucketName, Utils.urlencode(objectKey), None, header, object) 
        CHUNKSIZE = 65563 
        _flag = False
        try:
            _flag = os.path.isfile(unicode(file_path, "UTF-8"))
        except (UnicodeDecodeError, TypeError):
            _flag = os.path.isfile(file_path)
        if _flag:          
            self.send_message(conn, file_path)
        result = conn.getresponse()
        return GetResult.parse_xml(result)
    
    def setObjectAcl(self , bucketName, objectKey, acl=ACL(), versionId=None, aclControl=None):
        #===========================================================================
        # 修改对象的ACL。
        # @param bucketName    桶名。
        # @param objectKey     对象名。
        # @param acl           需要设置的ACL请求信息。
        # @param versionId     对象的版本号，标示更改指定版本的对象ACL。
        # @param aclControl    附加头域x-amz-acl值
        # @return GetResult    修改对象的ACL响应。
        #===========================================================================
        LOG(INFO, 'enter setObjectAcl ...')
        file_path = None
        if acl:
            file_path = acl.to_xml()
        obj = S3Object(file_path, None)
          
        path_args = {}
        path_args["acl"] = None
        if versionId:
            path_args["versionId"] = versionId
        headers = {}
        if aclControl is not None:
            headers['x-amz-acl'] = aclControl
        try:
            conn = self.make_request("PUT", bucketName, Utils.urlencode(objectKey), path_args, headers, obj)
              
            CHUNKSIZE = 65563
            if file_path:
                self.send_message(conn, file_path)
            result = conn.getresponse()
            return GetResult.parse_xml(result)
        finally:
            if file_path:
                os.remove(file_path) 
    
    def copyObject(self, sourceBucketName, sourceObjectKey, destBucketName, destObjectKey, metadata=None, headers=CopyObjectHeader(), versionId=None):
        #===========================================================================
        # 复制对象。
        # @param sourceBucketName 源桶名。
        # @param sourceObjectKey 源对象名。
        # @param destBucketName 桶名。
        # @param destObjectKey 对象名。
        # @param metadata 自定义元数据。
        # @param headers CopyObjectHeader,HTTP附加的消息头。
        # @param versionId 指定版本的复制对象。
        # @return GetResult GetResult.body:CopyObjectResponse 复制对象响应。
        #===========================================================================
        LOG(INFO, 'enter copyObject ...')
        copy_headers = headers.assemble_args() if headers else {}
        copy_source = '/%s/%s' % (sourceBucketName, sourceObjectKey) 
        if versionId:
            copy_source += "?versionId=%s" % (versionId)
        copy_headers["x-amz-copy-source"] = copy_source  
        obj = S3Object(None, metadata)
        conn = self.make_request("PUT", destBucketName, Utils.urlencode(destObjectKey), None, copy_headers, obj) 
        result = conn.getresponse()
        return GetResult.parse_xml(result)

    def restoreObject(self, bucketName, objectKey, days, tier=None, versionId=None):
        #===========================================================================
        # 取货归档存储对象。
        # @param bucketName 桶名。
        # @param objectKey  对象名。
        # @param days       取回对象的保存时间（单位：天），最小值为1，最大值为30。
        # @param tier       取回选项，支持三种取值：[Expedited|Standard|Bulk]。Expedited表示取回对象耗时1~5分钟，
        #                   Standard表示耗时3~5小时，Bulk表示耗时5~12小时。默认取值为Standard。
        # @param versionId  待取回冷存储对象的版本号。
        # @return GetResult 取回归档存储对象响应
        #===========================================================================
        LOG(INFO, 'enter restoreObject ...')
        path_args = {'restore': None}
        if versionId:
            path_args['versionId'] = str(versionId)

        restore = Restore(days, tier)
        content = restore.to_xml()
        headers = {'Content-MD5': Utils.md5_encode(content)}
        conn = self.make_request('POST',bucketName, Utils.urlencode(objectKey), path_args, headers, S3Object(file_size=len(content)))
        conn.send(content)
        result = conn.getresponse()
        return GetResult.parse_xml(result)

        
    def initiateMultipartUpload(self, bucketName, objectKey, acl=None, metadata=None, websiteRedirectLocation=None):
        #===========================================================================
        # 初始化多段上传任务。
        # @param bucketName              桶名。
        # @param objectKey               对象名。
        # @param acl                     ACL控制权限。
        # @param websiteRedirectLocation 当桶设置了Website配置，可以将获取这个对象的请求重定向到桶内另一个对象或一个外部的URL，UDS将这个值从头域中取出，保存在对象的元数据中，必须以“/”、“http://”或“https://”开头，长度不超过2K。
        # @return GetResult              GetResult.body:InitiateMultipartUploadResponse 初始化多段上传任务响应。
        #===========================================================================
        LOG(INFO, 'enter initiateMultipartUpload ...')
        path_args = {}
        path_args["uploads"] = None
        headers = {}
        if acl:
            headers["x-amz-acl"] = acl
        if metadata:
            for (k, v) in metadata.items():
                headers["x-amz-meta-" + k] = v
        if websiteRedirectLocation:
            headers["x-amz-website-redirect-location"] = websiteRedirectLocation
        conn = self.make_request("POST", bucketName, Utils.urlencode(objectKey), path_args, headers, None)
        result = conn.getresponse()
        return GetResult.parse_xml(result)


    def uploadPart(self , bucketName, objectKey, partNumber, uploadId, object, isFile=False, partSize=None, offset=0):
        #===========================================================================
        # 上传段。
        # @param bucketName   桶名。
        # @param objectKey    对象名。
        # @param partNumber   上传段的段号。
        # @param uploadId     多段上传任务的id。
        # @param file_path    上传对象路径。
        # @param isFile       传输的是否为文件，True传输文件，False传输元数据
        # @param partSize     多段上传任务中某一分段的大小，默认值为文件大小除去offset的剩下字节数，单位字节
        # @param offset       多段上传文件任务中某一分段偏移的大小，默认值为0, 单位字节
        # @return GetResult   上传段响应。
        #===========================================================================
        LOG(INFO, 'enter uploadPart ...')
        if isFile and ErrorMsg.is_file_not_exist(object):
            return ErrorMsg.GetError()

        path_args = {"partNumber": partNumber, "uploadId": uploadId}
        headers = {}
        file_path = None
        try:
            file_path = object if isFile else os.path.join(os.path.abspath(os.path.dirname(sys.argv[0])),"body.txt")
            file_path = Utils.safe_trans_file_path(file_path)

            if isFile:
                file_size = os.path.getsize(file_path)
                offset = offset if (isinstance(offset,int) or isinstance(offset, long)) and 0 <= offset < file_size else 0
                partSize = partSize if (isinstance(partSize,int) or isinstance(partSize, long)) and 0 < partSize <= file_size - offset else file_size - offset
            else:
                with open(file_path, "wb") as f:
                    f.write(object)
                file_size = os.path.getsize(file_path)
                offset = 0
                partSize = file_size

            headers["Content-MD5"] = Utils.base64_encode(Utils.md5_file_encode_by_size_offset(file_path,partSize,offset))
            conn = self.make_request("PUT", bucketName, Utils.urlencode(objectKey), path_args, headers, S3Object(file_path=file_path,file_size=partSize))
            self.send_message_part(conn, file_path, partSize, offset)
            result = conn.getresponse()
            return GetResult.parse_xml(result)
        finally:
            if not isFile:
                os.remove(file_path)
    
    def copyPart(self , bucketName, objectKey, partNumber, uploadId, copySource, copySourceRange=None):
        #===========================================================================
        # 拷贝段。
        # @param bucketName      桶名。
        # @param objectKey       对象名。
        # @param partNumber      上传段的段号。
        # @param uploadId        多段上传任务的id。
        # @param copySource      拷贝的源对象。
        # @param copySourceRange 源对象中待拷贝的段的字节范围（start - end），start为段起始字节，end为段结束字节。
        # @return GetResult      GetResult.body:CopyPartResponse 拷贝段响应。
        #===========================================================================
        LOG(INFO, 'enter copyPart ...')
        path_args = {"partNumber": partNumber, "uploadId": uploadId}
        obj = S3Object()
        headers = {}
        if copySource:
            headers["x-amz-copy-source"] = copySource
        if copySourceRange:
            headers["x-amz-copy-source-range"] = "bytes=" + str(copySourceRange)
        conn = self.make_request("PUT", bucketName, Utils.urlencode(objectKey), path_args, headers, obj)
        result = conn.getresponse() 
        return GetResult.parse_xml(result)
    
    def completeMultipartUpload(self , bucketName, objectKey, uploadId, completeMultipartUploadRequest=CompleteMultipartUploadRequest()):
        #===========================================================================
        # 合并段。
        # @param bucketName                     桶名。
        # @param objectKey                      对象名。
        # @param uploadId                       多段上传任务的id。
        # @param completeMultipartUploadRequest 合并段请求。
        # @return GetResult                     GetResult.body:CompleteMultipartUploadResponse 合并段响应。
        #===========================================================================
        LOG(INFO, 'enter completeMultipartUpload ...')
        file_path = None
        if completeMultipartUploadRequest:
            file_path = completeMultipartUploadRequest.to_xml()
        obj = S3Object(file_path, None)
        path_args = {}
        path_args["uploadId"] = uploadId
        try:
            conn = self.make_request("POST", bucketName, Utils.urlencode(objectKey), path_args, None, obj) 
            CHUNKSIZE = 65563  
            if file_path:          
                self.send_message(conn, file_path)
            result = conn.getresponse() 
            return GetResult.parse_xml(result)
        finally:
            if file_path:
                os.remove(file_path)
    
    def abortMultipartUpload(self , bucketName, objectKey, uploadId):
        #===========================================================================
        # 取消多段上传任务。
        # @param bucketName  桶名。
        # @param objectKey   获取要取消的多段上传任务上传的对象。
        # @param uploadId    多段上传任务的id。
        # @return GetResult  取消多段上传任务响应。
        #===========================================================================
        LOG(INFO, 'enter abortMultipartUpload ...')
        path_args = {}
        path_args["uploadId"] = uploadId
        conn = self.make_request("DELETE", bucketName, Utils.urlencode(objectKey), path_args, None, None)
        result = conn.getresponse() 
        return GetResult.parse_xml(result)
    
    def listParts(self, bucketName, objectKey, uploadId, maxParts=None, partNumberMarker=None):
        #===========================================================================
        # 列出段。
        # @param bucketName       桶名。
        # @param objectKey        对象名。
        # @param uploadId         多段上传任务的id。
        # @param maxParts         规定在列举已上传段响应中的最大Part数目。
        # @param partNumberMarker 指定List的起始位置，只有Part Number数目大于该参数的Part会被列出。
        # @return GetResult       GetResult.body:ListPartsResponse 列出段响应。
        #===========================================================================
        LOG(INFO, 'enter listParts ...')
        if ErrorMsg.is_obj_none(bucketName) or ErrorMsg.is_obj_none(objectKey):
            return ErrorMsg.GetError()
        path_args = {}
        path_args["uploadId"] = uploadId
        if maxParts:
            path_args["max-parts"] = maxParts
        if partNumberMarker:
            path_args["part-number-marker"] = partNumberMarker
        conn = self.make_request("GET", bucketName, Utils.urlencode(objectKey), path_args, None, None)
        result = conn.getresponse() 
        return GetResult.parse_xml(result)  
    
    def getBucketStorageInfo(self , bucketName):
        #===========================================================================
        # 获取桶存量。
        # @param bucketName 桶名。
        # @return GetResult GetResult.body:GetBucketStorageInfoResponse 获取桶存量响应。
        #===========================================================================
        LOG(INFO, 'enter getBucketStorageInfo ...')
        if ErrorMsg.is_obj_none(bucketName):
            return ErrorMsg.GetError()
        path_args = {}
        path_args["storageinfo"] = None
        conn = self.make_request("GET", bucketName, None, path_args, None, None)
        result = conn.getresponse() 
        return GetResult.parse_xml(result)  
        
    def getBucketQuota(self , bucketName):
        #===========================================================================
        # 获取桶配额。
        # @param bucketName 桶名。
        # @return GetResult GetResult.body:GetBucketQuotaResponse 获取桶配额响应。
        #===========================================================================
        LOG(INFO, 'enter getBucketQuota ...')
        if ErrorMsg.is_obj_none(bucketName):
            return ErrorMsg.GetError()
        path_args = {}
        path_args["quota"] = None
        conn = self.make_request("GET", bucketName, None, path_args, None, None)
        result = conn.getresponse() 
        return GetResult.parse_xml(result) 
        
    def setBucketQuota(self , bucketName, quota):
        #===========================================================================
        # 更新桶配额。
        # @param bucketName 桶名。
        # @param quota      指定桶空间配额值。
        # @return GetResult GetResult.body:GetBucketQuotaResponse 获取桶配额响应。
        #===========================================================================
        LOG(INFO, 'enter setBucketQuota ...')
        path_args = {}       
        path_args["quota"] = None
        str_list = []
        str_list.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>")
        str_list.append("<Quota xmlns=\"http://s3.amazonaws.com/doc/2006-03-01/\">")
        str_quota = "" if quota is None else str(quota)
        str_list.append("<StorageQuota>" + str_quota + "</StorageQuota>")
        str_list.append("</Quota>")
        
        s = ''.join(item for item in str_list)
       
        path = os.path.abspath(os.path.dirname(sys.argv[0]))
        file_path = os.path.join(path, "set_bucket_quota.xml")
        with open(file_path, 'wb') as f:
            f.write(s)
        obj = S3Object(file_path, None)
        try:
            conn = self.make_request("PUT", bucketName, None, path_args, None, obj)
            
            CHUNKSIZE = 65563
            if file_path:          
                self.send_message(conn, file_path)
            result = conn.getresponse() 
            return GetResult.parse_xml(result) 
        finally:
            if file_path:
                os.remove(file_path)

    def send_message_part(self, connect, file_path, part_size, offset):
        file_path = Utils.safe_trans_file_path(file_path)
        with open(file_path, 'rb') as f:
            CHUNKSIZE = 65536
            read_count = 0
            f.seek(offset)
            while read_count < part_size:
                read_size = CHUNKSIZE if part_size - read_count >= CHUNKSIZE else part_size - read_count
                chunk = f.read(read_size)
                read_count_once = len(chunk)
                if read_count_once <= 0:
                    break
                connect.send(chunk)
                read_count += read_count_once

    def send_message(self, connect , file_path):
        #===========================================================================
        # 读取文件，并发送文件内容。
        # @param connect      建立的连接。
        # @param file_path    文件路径。
        #===========================================================================
        methodName = sys._getframe().f_back.f_code.co_name
        method_put = sys._getframe().f_back.f_back.f_code.co_name
        file_path = Utils.safe_trans_file_path(file_path)
        CHUNKSIZE = 65563
        flag = methodName == "postObject" and not method_put == "putObject"
        if flag:
            LOG(DEBUG, 'send Path:%s' % file_path)
        with open(Utils.safe_trans_file_path(file_path), 'rb') as f:
            while True:
                chunk = f.read(CHUNKSIZE)
                if not chunk:
                    break
                connect.send(chunk)
                if not flag:
                    LOG(DEBUG, 'send Msg:%s', chunk)

    #===========================================================================
    # 生成Http请求（HttpConnection），带S3实体对象
    # @param method     HTTP方法(GET, PUT, DELETE)
    # @param bucketName 存储空间名
    # @param key        对象名
    # @param path_args  URL参数
    # @param headers    HTTP头
    # @param s3_object  将写入S3对象
    #===========================================================================
    def make_request(self, method, bucket, key, path_args, headers, s3_object):
        
        calling_format = Utils.get_callingformat_for_bucket(self.calling_format, bucket)
    
        if self.is_secure and not isinstance(calling_format, PathFormat) and bucket.find(".") != -1:
            raise Exception("You are making an SSL connection, however, the bucket contains periods and \
                            the wildcard certificate will not match by default. Please consider using HTTP.")
        path = calling_format.get_url(self.is_secure, self.server, self.port, bucket, key, path_args)
        connect_server = calling_format.get_server(self.server, bucket)  
        
        if s3_object:
            head = self.add_metadata_headers(self.add_headers(headers, ""), s3_object.metadata)
            if s3_object.file_size:
                head["Content-Length"] = str(s3_object.file_size)
            elif s3_object.file_path:
                file_path = Utils.safe_trans_file_path(s3_object.file_path)
                head["Content-Length"] = str(os.path.getsize(file_path)) if os.path.isfile(file_path) else str(0)
            else:
                head["Content-Length"] = str(0)
        else:
            head = self.add_headers(headers, "")
        if self.path_style == True:
            head["Host"] = self.server
        else:
            host = bucket + "." if bucket is not None and bucket != "" else ""
            head["Host"] = host + self.server
              
        headerconfig = self.add_auth_headers(head, method, bucket, key, path_args)
        headerLog = headerconfig.copy()
        headerLog['Host'] = '******'
        headerLog['Authorization'] = '******'
        LOG(DEBUG, 'method:%s, path:%s, header:%s', method, path, headerLog)
        return self.send_request(connect_server, method, path, headerconfig)
    
    #===========================================================================
    # 发送请求
    #===========================================================================
    def send_request(self, server, method, path, header):
        
        flag = 0
        while True:
            try:
                methodName = sys._getframe().f_back.f_back.f_code.co_name
                conn = self.get_server_connection(server)
                if methodName == "optionsBucket" or methodName == "optionsObject":
                    conn.putrequest(method, path)
                    for (k, v) in header.items():
                        if k == 'Access-Control-Request-Method':
                            for vlist in v:
                                conn.putheader('Access-Control-Request-Method', vlist)
                        elif k == 'Access-Control-Request-Headers':
                            for vlist in v:
                                conn.putheader('Access-Control-Request-Headers', vlist)
                        else:
                            conn.putheader(k, v)
                    conn.endheaders()             
                else:      
                    conn.request(method, path, headers=header)
                
            except socket.error, e:
                errno, errstr = sys.exc_info()[:2]
                if errno != socket.timeout or flag >= 3:
                    LOG(ERROR, 'connect service error')
                    raise e
                flag += 1
                LOG(DEBUG, 'connect service time out,connect again,connect time:%d', int(flag))
                continue
            break   
            
        return conn
    
    #===========================================================================
    # 获取服务器连接
    #===========================================================================
    def get_server_connection(self, server):
        if self.is_secure:
            import ssl
            LOG(DEBUG, 'is ssl_verify: %s',self.ssl_verify)
            if not self.ssl_verify and hasattr(ssl, '_create_unverified_context'):
                context = ssl._create_unverified_context()
                conn = httplib.HTTPSConnection(server, port=self.port, timeout=15, context=context)
            else:
                conn = httplib.HTTPSConnection(server, port=self.port, timeout=15)
        else:
            conn = httplib.HTTPConnection(server, port=self.port, timeout=15)
        return conn
       
    #===========================================================================
    # 为HttpConnection添加头
    # @param headers 需要在HTTP头中添加的字段，key-value格式的字典类型
    # @param prefix  在发起连接之前为每个头部字段添加前缀
    #===========================================================================
    def add_headers(self, headers, prefix):
        new_headers = {}
        if headers:       
            for i in headers.keys():
                key = str(i)
                value = headers.get(key)
                if type(value) is types.ListType:
                    tempList = []
                    for v in value:
                        tempList.append(urllib.quote(str(v), " ,:?/+=%"))
                    new_headers[(prefix + Utils.urlencode(key))] = tempList
                else:
                    new_headers[(prefix + Utils.urlencode(key))] = urllib.quote(str(value), " ,:?/+=%")  # 不编码的符号
        return new_headers

    #===========================================================================
    # 为HttpConnection添加可信的HTTP头
    # @param headers    将可信HTTP头添加到headers头中，字典型
    # @param method     HTTP方法（PUT,GET,DELETE)
    # @param bucketName 存储空间名
    # @param key        对象名
    # @param path_args  请求URL中的路径参数    
    #===========================================================================
    def add_auth_headers(self, headers, method, bucket, key, path_args):
        
        # 如果headers头中不存在Date和Content-Type或其值为空时，则添加
        if not headers.get("Date"):
            headers["Date"] = self.httpdate()
        
        if not headers.get("Content-Type"):
            headers["Content-Type"] = ""
        auth = ""
        if self.signature == "v4" or self.signature == "V4":
            if isinstance(path_args, (GetObjectRequest)):
                path_args = path_args.getArgsPath()
            V4 = V4Authentication(self.cryptor.decrypt_data(self.secret_access_key, self.pw_keyS, self.pw_ivS, self.key_ivS), \
                                  self.cryptor.decrypt_data(self.access_key_id, self.pw_keyA, self.pw_ivA, self.key_ivA), self.region)
            auth = V4.v4Auth(method, bucket, key, path_args, headers)
        else:
            canonical_string = Utils.make_canonicalstring(method, bucket, key, path_args, headers, None)
            encoded_canonical = Utils.encode(self.cryptor.decrypt_data(self.secret_access_key, self.pw_keyS, self.pw_ivS, self.key_ivS), canonical_string, False)              
            auth = "AWS " + self.cryptor.decrypt_data(self.access_key_id, self.pw_keyA, self.pw_ivA, self.key_ivA) + ":" + encoded_canonical  # 字符串连接
        headers["Authorization"] = auth
        return headers
       
    #=========================================================================
    # HttpConnection中添加元数据(metadata)字段
    # @param metadata s3对象中的元数据
    #=========================================================================
    def add_metadata_headers(self, headers, metadata): 
        if metadata:       
            for i in metadata.keys():
                key = str(i)
                value = str(unicode(metadata.get(key), "UTF-8"))
                headers[(Utils.METADATA_PREFIX + Utils.urlencode(key))] = Utils.urlencode(value)
        return headers
           
    #===========================================================================
    # 为HTTP头的Date字段生成rfc822格式的时间
    #===========================================================================
    def httpdate(self):        
        
        GMT_FORMAT = "%a, %d %b %Y %H:%M:%S GMT"
        date = datetime.datetime.utcnow().strftime(GMT_FORMAT)  # 用当前时间来生成datetime对象       
        return date

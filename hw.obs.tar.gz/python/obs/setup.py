#-*- coding:utf-8 -*-
from setuptools import setup, find_packages

setup(
        name = "ObsPythonSDK",
        version="1.0.0",
        packages = find_packages(),
        zip_safe = False,

        description = "eSDK OBS Python SDK",
        long_description = "Huawei IT Python SDK",
        author = "huawei",

        license = "GPL",
        keywords = ("obs", "python"),
        platforms = "Independant",
        url = "",
        )
